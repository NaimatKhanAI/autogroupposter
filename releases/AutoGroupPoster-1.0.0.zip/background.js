// node_modules/@firebase/util/dist/postinstall.mjs
var e = () => void 0, t = function(e) {
	let t = [], n = 0;
	for (let r = 0; r < e.length; r++) {
		let i = e.charCodeAt(r);
		i < 128 ? t[n++] = i : i < 2048 ? (t[n++] = i >> 6 | 192, t[n++] = i & 63 | 128) : (i & 64512) == 55296 && r + 1 < e.length && (e.charCodeAt(r + 1) & 64512) == 56320 ? (i = 65536 + ((i & 1023) << 10) + (e.charCodeAt(++r) & 1023), t[n++] = i >> 18 | 240, t[n++] = i >> 12 & 63 | 128, t[n++] = i >> 6 & 63 | 128, t[n++] = i & 63 | 128) : (t[n++] = i >> 12 | 224, t[n++] = i >> 6 & 63 | 128, t[n++] = i & 63 | 128);
	}
	return t;
}, n = function(e) {
	let t = [], n = 0, r = 0;
	for (; n < e.length;) {
		let i = e[n++];
		if (i < 128) t[r++] = String.fromCharCode(i);
		else if (i > 191 && i < 224) {
			let a = e[n++];
			t[r++] = String.fromCharCode((i & 31) << 6 | a & 63);
		} else if (i > 239 && i < 365) {
			let a = e[n++], o = e[n++], s = e[n++], c = ((i & 7) << 18 | (a & 63) << 12 | (o & 63) << 6 | s & 63) - 65536;
			t[r++] = String.fromCharCode(55296 + (c >> 10)), t[r++] = String.fromCharCode(56320 + (c & 1023));
		} else {
			let a = e[n++], o = e[n++];
			t[r++] = String.fromCharCode((i & 15) << 12 | (a & 63) << 6 | o & 63);
		}
	}
	return t.join("");
}, r = {
	byteToCharMap_: null,
	charToByteMap_: null,
	byteToCharMapWebSafe_: null,
	charToByteMapWebSafe_: null,
	ENCODED_VALS_BASE: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
	get ENCODED_VALS() {
		return this.ENCODED_VALS_BASE + "+/=";
	},
	get ENCODED_VALS_WEBSAFE() {
		return this.ENCODED_VALS_BASE + "-_.";
	},
	HAS_NATIVE_SUPPORT: typeof atob == "function",
	encodeByteArray(e, t) {
		if (!Array.isArray(e)) throw Error("encodeByteArray takes an array as a parameter");
		this.init_();
		let n = t ? this.byteToCharMapWebSafe_ : this.byteToCharMap_, r = [];
		for (let t = 0; t < e.length; t += 3) {
			let i = e[t], a = t + 1 < e.length, o = a ? e[t + 1] : 0, s = t + 2 < e.length, c = s ? e[t + 2] : 0, l = i >> 2, u = (i & 3) << 4 | o >> 4, d = (o & 15) << 2 | c >> 6, f = c & 63;
			s || (f = 64, a || (d = 64)), r.push(n[l], n[u], n[d], n[f]);
		}
		return r.join("");
	},
	encodeString(e, n) {
		return this.HAS_NATIVE_SUPPORT && !n ? btoa(e) : this.encodeByteArray(t(e), n);
	},
	decodeString(e, t) {
		return this.HAS_NATIVE_SUPPORT && !t ? atob(e) : n(this.decodeStringToByteArray(e, t));
	},
	decodeStringToByteArray(e, t) {
		this.init_();
		let n = t ? this.charToByteMapWebSafe_ : this.charToByteMap_, r = [];
		for (let t = 0; t < e.length;) {
			let a = n[e.charAt(t++)], o = t < e.length ? n[e.charAt(t)] : 0;
			++t;
			let s = t < e.length ? n[e.charAt(t)] : 64;
			++t;
			let c = t < e.length ? n[e.charAt(t)] : 64;
			if (++t, a == null || o == null || s == null || c == null) throw new i();
			let l = a << 2 | o >> 4;
			if (r.push(l), s !== 64) {
				let e = o << 4 & 240 | s >> 2;
				if (r.push(e), c !== 64) {
					let e = s << 6 & 192 | c;
					r.push(e);
				}
			}
		}
		return r;
	},
	init_() {
		if (!this.byteToCharMap_) {
			this.byteToCharMap_ = {}, this.charToByteMap_ = {}, this.byteToCharMapWebSafe_ = {}, this.charToByteMapWebSafe_ = {};
			for (let e = 0; e < this.ENCODED_VALS.length; e++) this.byteToCharMap_[e] = this.ENCODED_VALS.charAt(e), this.charToByteMap_[this.byteToCharMap_[e]] = e, this.byteToCharMapWebSafe_[e] = this.ENCODED_VALS_WEBSAFE.charAt(e), this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[e]] = e, e >= this.ENCODED_VALS_BASE.length && (this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(e)] = e, this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(e)] = e);
		}
	}
}, i = class extends Error {
	constructor() {
		super(...arguments), this.name = "DecodeBase64StringError";
	}
}, a = function(e) {
	let n = t(e);
	return r.encodeByteArray(n, !0);
}, o = function(e) {
	return a(e).replace(/\./g, "");
}, s = function(e) {
	try {
		return r.decodeString(e, !0);
	} catch (e) {
		console.error("base64Decode failed: ", e);
	}
	return null;
};
function c() {
	if (typeof self < "u") return self;
	if (typeof window < "u") return window;
	if (typeof global < "u") return global;
	throw Error("Unable to locate global object.");
}
var l = () => c().__FIREBASE_DEFAULTS__, u = () => {
	if (typeof process > "u" || process.env === void 0) return;
	let e = process.env.__FIREBASE_DEFAULTS__;
	if (e) return JSON.parse(e);
}, d = () => {
	if (typeof document > "u") return;
	let e;
	try {
		e = document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/);
	} catch {
		return;
	}
	let t = e && s(e[1]);
	return t && JSON.parse(t);
}, f = () => {
	try {
		return e() || l() || u() || d();
	} catch (e) {
		console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${e}`);
		return;
	}
}, p = (e) => f()?.emulatorHosts?.[e], m = (e) => {
	let t = p(e);
	if (!t) return;
	let n = t.lastIndexOf(":");
	if (n <= 0 || n + 1 === t.length) throw Error(`Invalid host ${t} with no separate hostname and port!`);
	let r = parseInt(t.substring(n + 1), 10);
	return t[0] === "[" ? [t.substring(1, n - 1), r] : [t.substring(0, n), r];
}, h = () => f()?.config, ee = class {
	constructor() {
		this.reject = () => {}, this.resolve = () => {}, this.promise = new Promise((e, t) => {
			this.resolve = e, this.reject = t;
		});
	}
	wrapCallback(e) {
		return (t, n) => {
			t ? this.reject(t) : this.resolve(n), typeof e == "function" && (this.promise.catch(() => {}), e.length === 1 ? e(t) : e(t, n));
		};
	}
};
function g(e, t) {
	if (e.uid) throw Error("The \"uid\" field is no longer supported by mockUserToken. Please use \"sub\" instead for Firebase Auth User ID.");
	let n = {
		alg: "none",
		type: "JWT"
	}, r = t || "demo-project", i = e.iat || 0, a = e.sub || e.user_id;
	if (!a) throw Error("mockUserToken must contain 'sub' or 'user_id' field!");
	let s = {
		iss: `https://securetoken.google.com/${r}`,
		aud: r,
		iat: i,
		exp: i + 3600,
		auth_time: i,
		sub: a,
		user_id: a,
		firebase: {
			sign_in_provider: "custom",
			identities: {}
		},
		...e
	};
	return [
		o(JSON.stringify(n)),
		o(JSON.stringify(s)),
		""
	].join(".");
}
function _() {
	return typeof navigator < "u" && typeof navigator.userAgent == "string" ? navigator.userAgent : "";
}
function te() {
	return typeof window < "u" && !!(window.cordova || window.phonegap || window.PhoneGap) && /ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(_());
}
function ne() {
	return typeof navigator < "u" && navigator.userAgent === "Cloudflare-Workers";
}
function re() {
	let e = typeof chrome == "object" ? chrome.runtime : typeof browser == "object" ? browser.runtime : void 0;
	return typeof e == "object" && e.id !== void 0;
}
function ie() {
	return typeof navigator == "object" && navigator.product === "ReactNative";
}
function ae() {
	try {
		return typeof indexedDB == "object";
	} catch {
		return !1;
	}
}
function oe() {
	return new Promise((e, t) => {
		try {
			let n = !0, r = "validate-browser-context-for-indexeddb-analytics-module", i = self.indexedDB.open(r);
			i.onsuccess = () => {
				i.result.close(), n || self.indexedDB.deleteDatabase(r), e(!0);
			}, i.onupgradeneeded = () => {
				n = !1;
			}, i.onerror = () => {
				t(i.error?.message || "");
			};
		} catch (e) {
			t(e);
		}
	});
}
var se = "FirebaseError", v = class e extends Error {
	constructor(t, n, r) {
		super(n), this.code = t, this.customData = r, this.name = se, Object.setPrototypeOf(this, e.prototype), Error.captureStackTrace && Error.captureStackTrace(this, y.prototype.create);
	}
}, y = class {
	constructor(e, t, n) {
		this.service = e, this.serviceName = t, this.errors = n;
	}
	create(e, ...t) {
		let n = t[0] || {}, r = `${this.service}/${e}`, i = this.errors[e], a = i ? ce(i, n) : "Error";
		return new v(r, `${this.serviceName}: ${a} (${r}).`, n);
	}
};
function ce(e, t) {
	try {
		let n = 0, r = "";
		for (; n < e.length;) {
			let i = e.indexOf("{$", n);
			if (i === -1) {
				r += e.substring(n);
				break;
			}
			let a = e.indexOf("}", i + 2);
			if (a === -1) {
				r += e.substring(n);
				break;
			}
			let o = e.substring(i + 2, a), s = t[o];
			r += e.substring(n, i) + (s == null ? `<${o}?>` : String(s)), n = a + 1;
		}
		return r;
	} catch {
		return e;
	}
}
function b(e, t) {
	if (e === t) return !0;
	let n = Object.keys(e), r = Object.keys(t);
	for (let i of n) {
		if (!r.includes(i)) return !1;
		let n = e[i], a = t[i];
		if (le(n) && le(a)) {
			if (!b(n, a)) return !1;
		} else if (n !== a) return !1;
	}
	for (let e of r) if (!n.includes(e)) return !1;
	return !0;
}
function le(e) {
	return typeof e == "object" && !!e;
}
function ue(e) {
	let t = [];
	for (let [n, r] of Object.entries(e)) Array.isArray(r) ? r.forEach((e) => {
		t.push(encodeURIComponent(n) + "=" + encodeURIComponent(e));
	}) : t.push(encodeURIComponent(n) + "=" + encodeURIComponent(r));
	return t.length ? "&" + t.join("&") : "";
}
function de(e, t) {
	let n = new fe(e, t);
	return n.subscribe.bind(n);
}
var fe = class {
	constructor(e, t) {
		this.observers = [], this.unsubscribes = [], this.observerCount = 0, this.task = Promise.resolve(), this.finalized = !1, this.onNoObservers = t, this.task.then(() => {
			e(this);
		}).catch((e) => {
			this.error(e);
		});
	}
	next(e) {
		this.forEachObserver((t) => {
			t.next(e);
		});
	}
	error(e) {
		this.forEachObserver((t) => {
			t.error(e);
		}), this.close(e);
	}
	complete() {
		this.forEachObserver((e) => {
			e.complete();
		}), this.close();
	}
	subscribe(e, t, n) {
		let r;
		if (e === void 0 && t === void 0 && n === void 0) throw Error("Missing Observer.");
		r = pe(e, [
			"next",
			"error",
			"complete"
		]) ? e : {
			next: e,
			error: t,
			complete: n
		}, r.next === void 0 && (r.next = me), r.error === void 0 && (r.error = me), r.complete === void 0 && (r.complete = me);
		let i = this.unsubscribeOne.bind(this, this.observers.length);
		return this.finalized && this.task.then(() => {
			try {
				this.finalError ? r.error(this.finalError) : r.complete();
			} catch {}
		}), this.observers.push(r), i;
	}
	unsubscribeOne(e) {
		this.observers !== void 0 && this.observers[e] !== void 0 && (delete this.observers[e], --this.observerCount, this.observerCount === 0 && this.onNoObservers !== void 0 && this.onNoObservers(this));
	}
	forEachObserver(e) {
		if (!this.finalized) for (let t = 0; t < this.observers.length; t++) this.sendOne(t, e);
	}
	sendOne(e, t) {
		this.task.then(() => {
			if (this.observers !== void 0 && this.observers[e] !== void 0) try {
				t(this.observers[e]);
			} catch (e) {
				typeof console < "u" && console.error && console.error(e);
			}
		});
	}
	close(e) {
		this.finalized || (this.finalized = !0, e !== void 0 && (this.finalError = e), this.task.then(() => {
			this.observers = void 0, this.onNoObservers = void 0;
		}));
	}
};
function pe(e, t) {
	if (typeof e != "object" || !e) return !1;
	for (let n of t) if (n in e && typeof e[n] == "function") return !0;
	return !1;
}
function me() {}
function x(e) {
	return e && e._delegate ? e._delegate : e;
}
function S(e) {
	try {
		return (e.startsWith("http://") || e.startsWith("https://") ? new URL(e).hostname : e).endsWith(".cloudworkstations.dev");
	} catch {
		return !1;
	}
}
async function he(e) {
	return (await fetch(e, { credentials: "include" })).ok;
}
// node_modules/@firebase/component/dist/esm/index.esm.js
var C = class {
	constructor(e, t, n) {
		this.name = e, this.instanceFactory = t, this.type = n, this.multipleInstances = !1, this.serviceProps = {}, this.instantiationMode = "LAZY", this.onInstanceCreated = null;
	}
	setInstantiationMode(e) {
		return this.instantiationMode = e, this;
	}
	setMultipleInstances(e) {
		return this.multipleInstances = e, this;
	}
	setServiceProps(e) {
		return this.serviceProps = e, this;
	}
	setInstanceCreatedCallback(e) {
		return this.onInstanceCreated = e, this;
	}
}, w = "[DEFAULT]", ge = class {
	constructor(e, t) {
		this.name = e, this.container = t, this.component = null, this.instances = /* @__PURE__ */ new Map(), this.instancesDeferred = /* @__PURE__ */ new Map(), this.instancesOptions = /* @__PURE__ */ new Map(), this.onInitCallbacks = /* @__PURE__ */ new Map();
	}
	get(e) {
		let t = this.normalizeInstanceIdentifier(e);
		if (!this.instancesDeferred.has(t)) {
			let e = new ee();
			if (this.instancesDeferred.set(t, e), this.isInitialized(t) || this.shouldAutoInitialize()) try {
				let n = this.getOrInitializeService({ instanceIdentifier: t });
				n && e.resolve(n);
			} catch {}
		}
		return this.instancesDeferred.get(t).promise;
	}
	getImmediate(e) {
		let t = this.normalizeInstanceIdentifier(e?.identifier), n = e?.optional ?? !1;
		if (this.isInitialized(t) || this.shouldAutoInitialize()) try {
			return this.getOrInitializeService({ instanceIdentifier: t });
		} catch (e) {
			if (n) return null;
			throw e;
		}
		if (n) return null;
		throw Error(`Service ${this.name} is not available`);
	}
	getComponent() {
		return this.component;
	}
	setComponent(e) {
		if (e.name !== this.name) throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);
		if (this.component) throw Error(`Component for ${this.name} has already been provided`);
		if (this.component = e, this.shouldAutoInitialize()) {
			if (ve(e)) try {
				this.getOrInitializeService({ instanceIdentifier: w });
			} catch {}
			for (let [e, t] of this.instancesDeferred.entries()) {
				let n = this.normalizeInstanceIdentifier(e);
				try {
					let e = this.getOrInitializeService({ instanceIdentifier: n });
					t.resolve(e);
				} catch {}
			}
		}
	}
	clearInstance(e = w) {
		this.instancesDeferred.delete(e), this.instancesOptions.delete(e), this.instances.delete(e);
	}
	async delete() {
		let e = Array.from(this.instances.values());
		await Promise.all([...e.filter((e) => "INTERNAL" in e).map((e) => e.INTERNAL.delete()), ...e.filter((e) => "_delete" in e).map((e) => e._delete())]);
	}
	isComponentSet() {
		return this.component != null;
	}
	isInitialized(e = w) {
		return this.instances.has(e);
	}
	getOptions(e = w) {
		return this.instancesOptions.get(e) || {};
	}
	initialize(e = {}) {
		let { options: t = {} } = e, n = this.normalizeInstanceIdentifier(e.instanceIdentifier);
		if (this.isInitialized(n)) throw Error(`${this.name}(${n}) has already been initialized`);
		if (!this.isComponentSet()) throw Error(`Component ${this.name} has not been registered yet`);
		let r = this.getOrInitializeService({
			instanceIdentifier: n,
			options: t
		});
		for (let [e, t] of this.instancesDeferred.entries()) n === this.normalizeInstanceIdentifier(e) && t.resolve(r);
		return r;
	}
	onInit(e, t) {
		let n = this.normalizeInstanceIdentifier(t), r = this.onInitCallbacks.get(n) ?? /* @__PURE__ */ new Set();
		r.add(e), this.onInitCallbacks.set(n, r);
		let i = this.instances.get(n);
		return i && e(i, n), () => {
			r.delete(e);
		};
	}
	invokeOnInitCallbacks(e, t) {
		let n = this.onInitCallbacks.get(t);
		if (n) for (let r of n) try {
			r(e, t);
		} catch {}
	}
	getOrInitializeService({ instanceIdentifier: e, options: t = {} }) {
		let n = this.instances.get(e);
		if (!n && this.component && (n = this.component.instanceFactory(this.container, {
			instanceIdentifier: _e(e),
			options: t
		}), this.instances.set(e, n), this.instancesOptions.set(e, t), this.invokeOnInitCallbacks(n, e), this.component.onInstanceCreated)) try {
			this.component.onInstanceCreated(this.container, e, n);
		} catch {}
		return n || null;
	}
	normalizeInstanceIdentifier(e = w) {
		return this.component ? this.component.multipleInstances ? e : w : e;
	}
	shouldAutoInitialize() {
		return !!this.component && this.component.instantiationMode !== "EXPLICIT";
	}
};
function _e(e) {
	return e === w ? void 0 : e;
}
function ve(e) {
	return e.instantiationMode === "EAGER";
}
var ye = class {
	constructor(e) {
		this.name = e, this.providers = /* @__PURE__ */ new Map();
	}
	addComponent(e) {
		let t = this.getProvider(e.name);
		if (t.isComponentSet()) throw Error(`Component ${e.name} has already been registered with ${this.name}`);
		t.setComponent(e);
	}
	addOrOverwriteComponent(e) {
		this.getProvider(e.name).isComponentSet() && this.providers.delete(e.name), this.addComponent(e);
	}
	getProvider(e) {
		if (this.providers.has(e)) return this.providers.get(e);
		let t = new ge(e, this);
		return this.providers.set(e, t), t;
	}
	getProviders() {
		return Array.from(this.providers.values());
	}
}, be = [], T;
(function(e) {
	e[e.DEBUG = 0] = "DEBUG", e[e.VERBOSE = 1] = "VERBOSE", e[e.INFO = 2] = "INFO", e[e.WARN = 3] = "WARN", e[e.ERROR = 4] = "ERROR", e[e.SILENT = 5] = "SILENT";
})(T ||= {});
var xe = {
	debug: T.DEBUG,
	verbose: T.VERBOSE,
	info: T.INFO,
	warn: T.WARN,
	error: T.ERROR,
	silent: T.SILENT
}, Se = T.INFO, Ce = {
	[T.DEBUG]: "log",
	[T.VERBOSE]: "log",
	[T.INFO]: "info",
	[T.WARN]: "warn",
	[T.ERROR]: "error"
}, we = (e, t, ...n) => {
	if (t < e.logLevel) return;
	let r = (/* @__PURE__ */ new Date()).toISOString(), i = Ce[t];
	if (i) console[i](`[${r}]  ${e.name}:`, ...n);
	else throw Error(`Attempted to log a message with an invalid logType (value: ${t})`);
}, Te = class {
	constructor(e) {
		this.name = e, this._logLevel = Se, this._logHandler = we, this._userLogHandler = null, be.push(this);
	}
	get logLevel() {
		return this._logLevel;
	}
	set logLevel(e) {
		if (!(e in T)) throw TypeError(`Invalid value "${e}" assigned to \`logLevel\``);
		this._logLevel = e;
	}
	setLogLevel(e) {
		this._logLevel = typeof e == "string" ? xe[e] : e;
	}
	get logHandler() {
		return this._logHandler;
	}
	set logHandler(e) {
		if (typeof e != "function") throw TypeError("Value assigned to `logHandler` must be a function");
		this._logHandler = e;
	}
	get userLogHandler() {
		return this._userLogHandler;
	}
	set userLogHandler(e) {
		this._userLogHandler = e;
	}
	debug(...e) {
		this._userLogHandler && this._userLogHandler(this, T.DEBUG, ...e), this._logHandler(this, T.DEBUG, ...e);
	}
	log(...e) {
		this._userLogHandler && this._userLogHandler(this, T.VERBOSE, ...e), this._logHandler(this, T.VERBOSE, ...e);
	}
	info(...e) {
		this._userLogHandler && this._userLogHandler(this, T.INFO, ...e), this._logHandler(this, T.INFO, ...e);
	}
	warn(...e) {
		this._userLogHandler && this._userLogHandler(this, T.WARN, ...e), this._logHandler(this, T.WARN, ...e);
	}
	error(...e) {
		this._userLogHandler && this._userLogHandler(this, T.ERROR, ...e), this._logHandler(this, T.ERROR, ...e);
	}
}, Ee = (e, t) => t.some((t) => e instanceof t), De, Oe;
function ke() {
	return De ||= [
		IDBDatabase,
		IDBObjectStore,
		IDBIndex,
		IDBCursor,
		IDBTransaction
	];
}
function Ae() {
	return Oe ||= [
		IDBCursor.prototype.advance,
		IDBCursor.prototype.continue,
		IDBCursor.prototype.continuePrimaryKey
	];
}
var je = /* @__PURE__ */ new WeakMap(), Me = /* @__PURE__ */ new WeakMap(), Ne = /* @__PURE__ */ new WeakMap(), Pe = /* @__PURE__ */ new WeakMap(), Fe = /* @__PURE__ */ new WeakMap();
function Ie(e) {
	let t = new Promise((t, n) => {
		let r = () => {
			e.removeEventListener("success", i), e.removeEventListener("error", a);
		}, i = () => {
			t(E(e.result)), r();
		}, a = () => {
			n(e.error), r();
		};
		e.addEventListener("success", i), e.addEventListener("error", a);
	});
	return t.then((t) => {
		t instanceof IDBCursor && je.set(t, e);
	}).catch(() => {}), Fe.set(t, e), t;
}
function Le(e) {
	if (Me.has(e)) return;
	let t = new Promise((t, n) => {
		let r = () => {
			e.removeEventListener("complete", i), e.removeEventListener("error", a), e.removeEventListener("abort", a);
		}, i = () => {
			t(), r();
		}, a = () => {
			n(e.error || new DOMException("AbortError", "AbortError")), r();
		};
		e.addEventListener("complete", i), e.addEventListener("error", a), e.addEventListener("abort", a);
	});
	Me.set(e, t);
}
var Re = {
	get(e, t, n) {
		if (e instanceof IDBTransaction) {
			if (t === "done") return Me.get(e);
			if (t === "objectStoreNames") return e.objectStoreNames || Ne.get(e);
			if (t === "store") return n.objectStoreNames[1] ? void 0 : n.objectStore(n.objectStoreNames[0]);
		}
		return E(e[t]);
	},
	set(e, t, n) {
		return e[t] = n, !0;
	},
	has(e, t) {
		return e instanceof IDBTransaction && (t === "done" || t === "store") || t in e;
	}
};
function ze(e) {
	Re = e(Re);
}
function Be(e) {
	return e === IDBDatabase.prototype.transaction && !("objectStoreNames" in IDBTransaction.prototype) ? function(t, ...n) {
		let r = e.call(He(this), t, ...n);
		return Ne.set(r, t.sort ? t.sort() : [t]), E(r);
	} : Ae().includes(e) ? function(...t) {
		return e.apply(He(this), t), E(je.get(this));
	} : function(...t) {
		return E(e.apply(He(this), t));
	};
}
function Ve(e) {
	return typeof e == "function" ? Be(e) : (e instanceof IDBTransaction && Le(e), Ee(e, ke()) ? new Proxy(e, Re) : e);
}
function E(e) {
	if (e instanceof IDBRequest) return Ie(e);
	if (Pe.has(e)) return Pe.get(e);
	let t = Ve(e);
	return t !== e && (Pe.set(e, t), Fe.set(t, e)), t;
}
var He = (e) => Fe.get(e);
// node_modules/idb/build/index.js
function Ue(e, t, { blocked: n, upgrade: r, blocking: i, terminated: a } = {}) {
	let o = indexedDB.open(e, t), s = E(o);
	return r && o.addEventListener("upgradeneeded", (e) => {
		r(E(o.result), e.oldVersion, e.newVersion, E(o.transaction), e);
	}), n && o.addEventListener("blocked", (e) => n(e.oldVersion, e.newVersion, e)), s.then((e) => {
		a && e.addEventListener("close", () => a()), i && e.addEventListener("versionchange", (e) => i(e.oldVersion, e.newVersion, e));
	}).catch(() => {}), s;
}
var We = [
	"get",
	"getKey",
	"getAll",
	"getAllKeys",
	"count"
], Ge = [
	"put",
	"add",
	"delete",
	"clear"
], Ke = /* @__PURE__ */ new Map();
function qe(e, t) {
	if (!(e instanceof IDBDatabase && !(t in e) && typeof t == "string")) return;
	if (Ke.get(t)) return Ke.get(t);
	let n = t.replace(/FromIndex$/, ""), r = t !== n, i = Ge.includes(n);
	if (!(n in (r ? IDBIndex : IDBObjectStore).prototype) || !(i || We.includes(n))) return;
	let a = async function(e, ...t) {
		let a = this.transaction(e, i ? "readwrite" : "readonly"), o = a.store;
		return r && (o = o.index(t.shift())), (await Promise.all([o[n](...t), i && a.done]))[0];
	};
	return Ke.set(t, a), a;
}
ze((e) => ({
	...e,
	get: (t, n, r) => qe(t, n) || e.get(t, n, r),
	has: (t, n) => !!qe(t, n) || e.has(t, n)
}));
// node_modules/@firebase/app/dist/esm/index.esm.js
var Je = class {
	constructor(e) {
		this.container = e;
	}
	getPlatformInfoString() {
		return this.container.getProviders().map((e) => {
			if (Ye(e)) {
				let t = e.getImmediate();
				return `${t.library}/${t.version}`;
			}
			return null;
		}).filter((e) => e).join(" ");
	}
};
function Ye(e) {
	return e.getComponent()?.type === "VERSION";
}
var Xe = "@firebase/app", Ze = "0.16.4", D = new Te("@firebase/app"), Qe = "@firebase/app-compat", $e = "@firebase/analytics-compat", et = "@firebase/analytics", tt = "@firebase/app-check-compat", nt = "@firebase/app-check", rt = "@firebase/auth", it = "@firebase/auth-compat", at = "@firebase/database", ot = "@firebase/data-connect", st = "@firebase/database-compat", ct = "@firebase/functions", lt = "@firebase/functions-compat", ut = "@firebase/installations", dt = "@firebase/installations-compat", ft = "@firebase/messaging", pt = "@firebase/messaging-compat", mt = "@firebase/performance", ht = "@firebase/performance-compat", gt = "@firebase/remote-config", _t = "@firebase/remote-config-compat", vt = "@firebase/storage", yt = "@firebase/storage-compat", bt = "@firebase/firestore", xt = "@firebase/ai", St = "@firebase/firestore-compat", Ct = "firebase", wt = "13.1.0", Tt = "[DEFAULT]", Et = {
	[Xe]: "fire-core",
	[Qe]: "fire-core-compat",
	[et]: "fire-analytics",
	[$e]: "fire-analytics-compat",
	[nt]: "fire-app-check",
	[tt]: "fire-app-check-compat",
	[rt]: "fire-auth",
	[it]: "fire-auth-compat",
	[at]: "fire-rtdb",
	[ot]: "fire-data-connect",
	[st]: "fire-rtdb-compat",
	[ct]: "fire-fn",
	[lt]: "fire-fn-compat",
	[ut]: "fire-iid",
	[dt]: "fire-iid-compat",
	[ft]: "fire-fcm",
	[pt]: "fire-fcm-compat",
	[mt]: "fire-perf",
	[ht]: "fire-perf-compat",
	[gt]: "fire-rc",
	[_t]: "fire-rc-compat",
	[vt]: "fire-gcs",
	[yt]: "fire-gcs-compat",
	[bt]: "fire-fst",
	[St]: "fire-fst-compat",
	[xt]: "fire-vertex",
	"fire-js": "fire-js",
	[Ct]: "fire-js-all"
}, Dt = /* @__PURE__ */ new Map(), Ot = /* @__PURE__ */ new Map(), kt = /* @__PURE__ */ new Map();
function At(e, t) {
	try {
		e.container.addComponent(t);
	} catch (n) {
		D.debug(`Component ${t.name} failed to register with FirebaseApp ${e.name}`, n);
	}
}
function O(e) {
	let t = e.name;
	if (kt.has(t)) return D.debug(`There were multiple attempts to register component ${t}.`), !1;
	kt.set(t, e);
	for (let t of Dt.values()) At(t, e);
	for (let t of Ot.values()) At(t, e);
	return !0;
}
function jt(e, t) {
	let n = e.container.getProvider("heartbeat").getImmediate({ optional: !0 });
	return n && n.triggerHeartbeat(), e.container.getProvider(t);
}
function k(e) {
	return e != null && e.settings !== void 0;
}
var A = new y("app", "Firebase", {
	"no-app": "No Firebase App '{$appName}' has been created - call initializeApp() first",
	"bad-app-name": "Illegal App name: '{$appName}'",
	"duplicate-app": "Firebase App named '{$appName}' already exists with different {$mismatchedParam}. Existing: '{$oldValue}'. New: '{$newValue}'.",
	"app-deleted": "Firebase App named '{$appName}' already deleted",
	"server-app-deleted": "Firebase Server App has been deleted",
	"no-options": "Need to provide options, when not being deployed to hosting via source.",
	"invalid-app-argument": "firebase.{$appName}() takes either no argument or a Firebase App instance.",
	"invalid-log-argument": "First argument to `onLog` must be null or a function.",
	"idb-open": "Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.",
	"idb-get": "Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.",
	"idb-set": "Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.",
	"idb-delete": "Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.",
	"finalization-registry-not-supported": "FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.",
	"invalid-server-app-environment": "FirebaseServerApp is not for use in browser environments."
}), Mt = class {
	constructor(e, t, n) {
		this._isDeleted = !1, this._options = { ...e }, this._config = { ...t }, this._name = t.name, this._automaticDataCollectionEnabled = t.automaticDataCollectionEnabled, this._container = n, this.container.addComponent(new C("app", () => this, "PUBLIC"));
	}
	get automaticDataCollectionEnabled() {
		return this.checkDestroyed(), this._automaticDataCollectionEnabled;
	}
	set automaticDataCollectionEnabled(e) {
		this.checkDestroyed(), this._automaticDataCollectionEnabled = e;
	}
	get name() {
		return this.checkDestroyed(), this._name;
	}
	get options() {
		return this.checkDestroyed(), this._options;
	}
	get config() {
		return this.checkDestroyed(), this._config;
	}
	get container() {
		return this._container;
	}
	get isDeleted() {
		return this._isDeleted;
	}
	set isDeleted(e) {
		this._isDeleted = e;
	}
	checkDestroyed() {
		if (this.isDeleted) throw A.create("app-deleted", { appName: this._name });
	}
}, j = wt;
function Nt(e, t = {}) {
	let n = e;
	typeof t != "object" && (t = { name: t });
	let r = {
		name: Tt,
		automaticDataCollectionEnabled: !0,
		...t
	}, i = r.name;
	if (typeof i != "string" || !i) throw A.create("bad-app-name", { appName: String(i) });
	if (n ||= h(), !n) throw A.create("no-options");
	let a = Dt.get(i);
	if (a) {
		if (!b(n, a.options)) throw A.create("duplicate-app", {
			appName: i,
			mismatchedParam: "options",
			oldValue: JSON.stringify(a.options),
			newValue: JSON.stringify(n)
		});
		if (b(r, a.config)) return a;
		throw A.create("duplicate-app", {
			appName: i,
			mismatchedParam: "config",
			oldValue: JSON.stringify(a.config),
			newValue: JSON.stringify(r)
		});
	}
	let o = new ye(i);
	for (let e of kt.values()) o.addComponent(e);
	let s = new Mt(n, r, o);
	return Dt.set(i, s), s;
}
function Pt(e = Tt) {
	let t = Dt.get(e);
	if (!t && e === "[DEFAULT]" && h()) return Nt();
	if (!t) throw A.create("no-app", { appName: e });
	return t;
}
function M(e, t, n) {
	let r = Et[e] ?? e;
	n && (r += `-${n}`);
	let i = r.match(/\s|\//), a = t.match(/\s|\//);
	if (i || a) {
		let e = [`Unable to register library "${r}" with version "${t}":`];
		i && e.push(`library name "${r}" contains illegal characters (whitespace or "/")`), i && a && e.push("and"), a && e.push(`version name "${t}" contains illegal characters (whitespace or "/")`), D.warn(e.join(" "));
	} else O(new C(`${r}-version`, () => ({
		library: r,
		version: t
	}), "VERSION"));
}
var Ft = "firebase-heartbeat-database", It = 1, N = "firebase-heartbeat-store", Lt = null;
function Rt() {
	return Lt ||= Ue(Ft, It, { upgrade: (e, t) => {
		if (t === 0) try {
			e.createObjectStore(N);
		} catch (e) {
			console.warn(e);
		}
	} }).catch((e) => {
		throw A.create("idb-open", { originalErrorMessage: e.message });
	}), Lt;
}
async function zt(e) {
	try {
		let t = (await Rt()).transaction(N), n = await t.objectStore(N).get(Vt(e));
		return await t.done, n;
	} catch (e) {
		if (e instanceof v) D.warn(e.message);
		else {
			let t = A.create("idb-get", { originalErrorMessage: e?.message });
			D.warn(t.message);
		}
	}
}
async function Bt(e, t) {
	try {
		let n = (await Rt()).transaction(N, "readwrite");
		await n.objectStore(N).put(t, Vt(e)), await n.done;
	} catch (e) {
		if (e instanceof v) D.warn(e.message);
		else {
			let t = A.create("idb-set", { originalErrorMessage: e?.message });
			D.warn(t.message);
		}
	}
}
function Vt(e) {
	return `${e.name}!${e.options.appId}`;
}
var Ht = 1024, Ut = 30, Wt = class {
	constructor(e) {
		this.container = e, this._heartbeatsCache = null;
		let t = this.container.getProvider("app").getImmediate();
		this._storage = new qt(t), this._heartbeatsCachePromise = this._storage.read().then((e) => (this._heartbeatsCache = e, e));
	}
	async triggerHeartbeat() {
		try {
			let e = this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(), t = Gt();
			if (this._heartbeatsCache?.heartbeats == null && (this._heartbeatsCache = await this._heartbeatsCachePromise, this._heartbeatsCache?.heartbeats == null) || this._heartbeatsCache.lastSentHeartbeatDate === t || this._heartbeatsCache.heartbeats.some((e) => e.date === t)) return;
			if (this._heartbeatsCache.heartbeats.push({
				date: t,
				agent: e
			}), this._heartbeatsCache.heartbeats.length > Ut) {
				let e = Yt(this._heartbeatsCache.heartbeats);
				this._heartbeatsCache.heartbeats.splice(e, 1);
			}
			return this._storage.overwrite(this._heartbeatsCache);
		} catch (e) {
			D.warn(e);
		}
	}
	async getHeartbeatsHeader() {
		try {
			if (this._heartbeatsCache === null && await this._heartbeatsCachePromise, this._heartbeatsCache?.heartbeats == null || this._heartbeatsCache.heartbeats.length === 0) return "";
			let e = Gt(), { heartbeatsToSend: t, unsentEntries: n } = Kt(this._heartbeatsCache.heartbeats), r = o(JSON.stringify({
				version: 2,
				heartbeats: t
			}));
			return this._heartbeatsCache.lastSentHeartbeatDate = e, n.length > 0 ? (this._heartbeatsCache.heartbeats = n, await this._storage.overwrite(this._heartbeatsCache)) : (this._heartbeatsCache.heartbeats = [], this._storage.overwrite(this._heartbeatsCache)), r;
		} catch (e) {
			return D.warn(e), "";
		}
	}
};
function Gt() {
	return (/* @__PURE__ */ new Date()).toISOString().substring(0, 10);
}
function Kt(e, t = Ht) {
	let n = [], r = e.slice();
	for (let i of e) {
		let e = n.find((e) => e.agent === i.agent);
		if (!e) {
			if (n.push({
				agent: i.agent,
				dates: [i.date]
			}), Jt(n) > t) {
				n.pop();
				break;
			}
		} else if (e.dates.push(i.date), Jt(n) > t) {
			e.dates.pop();
			break;
		}
		r = r.slice(1);
	}
	return {
		heartbeatsToSend: n,
		unsentEntries: r
	};
}
var qt = class {
	constructor(e) {
		this.app = e, this._canUseIndexedDBPromise = this.runIndexedDBEnvironmentCheck();
	}
	async runIndexedDBEnvironmentCheck() {
		return ae() ? oe().then(() => !0).catch(() => !1) : !1;
	}
	async read() {
		if (await this._canUseIndexedDBPromise) {
			let e = await zt(this.app);
			return e?.heartbeats ? e : { heartbeats: [] };
		}
		return { heartbeats: [] };
	}
	async overwrite(e) {
		if (await this._canUseIndexedDBPromise) {
			let t = await this.read();
			return Bt(this.app, {
				lastSentHeartbeatDate: e.lastSentHeartbeatDate ?? t.lastSentHeartbeatDate,
				heartbeats: e.heartbeats
			});
		}
	}
	async add(e) {
		if (await this._canUseIndexedDBPromise) {
			let t = await this.read();
			return Bt(this.app, {
				lastSentHeartbeatDate: e.lastSentHeartbeatDate ?? t.lastSentHeartbeatDate,
				heartbeats: [...t.heartbeats, ...e.heartbeats]
			});
		}
	}
};
function Jt(e) {
	return o(JSON.stringify({
		version: 2,
		heartbeats: e
	})).length;
}
function Yt(e) {
	if (e.length === 0) return -1;
	let t = 0, n = e[0].date;
	for (let r = 1; r < e.length; r++) e[r].date < n && (n = e[r].date, t = r);
	return t;
}
function Xt(e) {
	O(new C("platform-logger", (e) => new Je(e), "PRIVATE")), O(new C("heartbeat", (e) => new Wt(e), "PRIVATE")), M(Xe, Ze, e), M(Xe, Ze, "esm2020"), M("fire-js", "");
}
// node_modules/firebase/app/dist/esm/index.esm.js
Xt(""), M("firebase", "13.1.0", "app");
// node_modules/@firebase/auth/dist/web-extension-esm/register-1dTRtNx2.js
function Zt() {
	return { "dependent-sdk-initialized-before-auth": "Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK." };
}
var Qt = Zt, $t = new y("auth", "Firebase", Zt()), en = new Te("@firebase/auth");
function tn(e, ...t) {
	en.logLevel <= T.WARN && en.warn(`Auth (${j}): ${e}`, ...t);
}
function nn(e, ...t) {
	en.logLevel <= T.ERROR && en.error(`Auth (${j}): ${e}`, ...t);
}
function P(e, ...t) {
	throw sn(e, ...t);
}
function rn(e, ...t) {
	return sn(e, ...t);
}
function an(e, t, n) {
	return new y("auth", "Firebase", {
		...Qt(),
		[t]: n
	}).create(t, { appName: e.name });
}
function on(e) {
	return an(e, "operation-not-supported-in-this-environment", "Operations that alter the current user are not supported in conjunction with FirebaseServerApp");
}
function sn(e, ...t) {
	if (typeof e != "string") {
		let n = t[0], r = [...t.slice(1)];
		return r[0] && (r[0].appName = e.name), e._errorFactory.create(n, ...r);
	}
	return $t.create(e, ...t);
}
function F(e, t, ...n) {
	if (!e) throw sn(t, ...n);
}
function I(e) {
	let t = "INTERNAL ASSERTION FAILED: " + e;
	throw nn(t), Error(t);
}
function L(e, t) {
	e || I(t);
}
function cn() {
	return ln() === "http:" || ln() === "https:";
}
function ln() {
	return typeof self < "u" && self.location?.protocol || null;
}
function un() {
	return typeof navigator < "u" && navigator && "onLine" in navigator && typeof navigator.onLine == "boolean" && (cn() || re() || "connection" in navigator) ? navigator.onLine : !0;
}
function dn() {
	if (typeof navigator > "u") return null;
	let e = navigator;
	return e.languages && e.languages[0] || e.language || null;
}
var fn = class {
	constructor(e, t) {
		this.shortDelay = e, this.longDelay = t, L(t > e, "Short delay should be less than long delay!"), this.isMobile = te() || ie();
	}
	get() {
		return un() ? this.isMobile ? this.longDelay : this.shortDelay : Math.min(5e3, this.shortDelay);
	}
};
function pn(e, t) {
	L(e.emulator, "Emulator should always be set here");
	let { url: n } = e.emulator;
	return t ? `${n}${t.startsWith("/") ? t.slice(1) : t}` : n;
}
var mn = class {
	static initialize(e, t, n) {
		this.fetchImpl = e, t && (this.headersImpl = t), n && (this.responseImpl = n);
	}
	static fetch() {
		if (this.fetchImpl) return this.fetchImpl;
		if (typeof self < "u" && "fetch" in self) return self.fetch;
		if (typeof globalThis < "u" && globalThis.fetch) return globalThis.fetch;
		if (typeof fetch < "u") return fetch;
		I("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill");
	}
	static headers() {
		if (this.headersImpl) return this.headersImpl;
		if (typeof self < "u" && "Headers" in self) return self.Headers;
		if (typeof globalThis < "u" && globalThis.Headers) return globalThis.Headers;
		if (typeof Headers < "u") return Headers;
		I("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill");
	}
	static response() {
		if (this.responseImpl) return this.responseImpl;
		if (typeof self < "u" && "Response" in self) return self.Response;
		if (typeof globalThis < "u" && globalThis.Response) return globalThis.Response;
		if (typeof Response < "u") return Response;
		I("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill");
	}
}, hn = {
	CREDENTIAL_MISMATCH: "custom-token-mismatch",
	MISSING_CUSTOM_TOKEN: "internal-error",
	INVALID_IDENTIFIER: "invalid-email",
	MISSING_CONTINUE_URI: "internal-error",
	INVALID_PASSWORD: "wrong-password",
	MISSING_PASSWORD: "missing-password",
	INVALID_LOGIN_CREDENTIALS: "invalid-credential",
	EMAIL_EXISTS: "email-already-in-use",
	PASSWORD_LOGIN_DISABLED: "operation-not-allowed",
	INVALID_IDP_RESPONSE: "invalid-credential",
	INVALID_PENDING_TOKEN: "invalid-credential",
	FEDERATED_USER_ID_ALREADY_LINKED: "credential-already-in-use",
	MISSING_REQ_TYPE: "internal-error",
	EMAIL_NOT_FOUND: "user-not-found",
	RESET_PASSWORD_EXCEED_LIMIT: "too-many-requests",
	EXPIRED_OOB_CODE: "expired-action-code",
	INVALID_OOB_CODE: "invalid-action-code",
	MISSING_OOB_CODE: "internal-error",
	CREDENTIAL_TOO_OLD_LOGIN_AGAIN: "requires-recent-login",
	INVALID_ID_TOKEN: "invalid-user-token",
	TOKEN_EXPIRED: "user-token-expired",
	USER_NOT_FOUND: "user-token-expired",
	TOO_MANY_ATTEMPTS_TRY_LATER: "too-many-requests",
	PASSWORD_DOES_NOT_MEET_REQUIREMENTS: "password-does-not-meet-requirements",
	INVALID_CODE: "invalid-verification-code",
	INVALID_SESSION_INFO: "invalid-verification-id",
	INVALID_TEMPORARY_PROOF: "invalid-credential",
	MISSING_SESSION_INFO: "missing-verification-id",
	SESSION_EXPIRED: "code-expired",
	MISSING_ANDROID_PACKAGE_NAME: "missing-android-pkg-name",
	UNAUTHORIZED_DOMAIN: "unauthorized-continue-uri",
	INVALID_OAUTH_CLIENT_ID: "invalid-oauth-client-id",
	ADMIN_ONLY_OPERATION: "admin-restricted-operation",
	INVALID_MFA_PENDING_CREDENTIAL: "invalid-multi-factor-session",
	MFA_ENROLLMENT_NOT_FOUND: "multi-factor-info-not-found",
	MISSING_MFA_ENROLLMENT_ID: "missing-multi-factor-info",
	MISSING_MFA_PENDING_CREDENTIAL: "missing-multi-factor-session",
	SECOND_FACTOR_EXISTS: "second-factor-already-in-use",
	SECOND_FACTOR_LIMIT_EXCEEDED: "maximum-second-factor-count-exceeded",
	BLOCKING_FUNCTION_ERROR_RESPONSE: "internal-error",
	RECAPTCHA_NOT_ENABLED: "recaptcha-not-enabled",
	MISSING_RECAPTCHA_TOKEN: "missing-recaptcha-token",
	INVALID_RECAPTCHA_TOKEN: "invalid-recaptcha-token",
	INVALID_RECAPTCHA_ACTION: "invalid-recaptcha-action",
	MISSING_CLIENT_TYPE: "missing-client-type",
	MISSING_RECAPTCHA_VERSION: "missing-recaptcha-version",
	INVALID_RECAPTCHA_VERSION: "invalid-recaptcha-version",
	INVALID_REQ_TYPE: "invalid-req-type"
}, gn = [
	"/v1/accounts:signInWithCustomToken",
	"/v1/accounts:signInWithEmailLink",
	"/v1/accounts:signInWithIdp",
	"/v1/accounts:signInWithPassword",
	"/v1/accounts:signInWithPhoneNumber",
	"/v1/token"
], _n = new fn(3e4, 6e4);
function vn(e, t) {
	return e.tenantId && !t.tenantId ? {
		...t,
		tenantId: e.tenantId
	} : t;
}
async function R(e, t, n, r, i = {}) {
	return yn(e, i, async () => {
		let i = {}, a = {};
		r && (t === "GET" ? a = r : i = { body: JSON.stringify(r) });
		let o = ue({
			...a,
			key: e.config.apiKey
		}).slice(1), s = await e._getAdditionalHeaders();
		s["Content-Type"] = "application/json", e.languageCode && (s["X-Firebase-Locale"] = e.languageCode);
		let c = {
			method: t,
			headers: s,
			...i
		};
		return ne() || (c.referrerPolicy = "strict-origin-when-cross-origin"), e.emulatorConfig && S(e.emulatorConfig.host) && (c.credentials = "include"), mn.fetch()(await xn(e, e.config.apiHost, n, o), c);
	});
}
async function yn(e, t, n) {
	e._canInitEmulator = !1;
	let r = {
		...hn,
		...t
	};
	try {
		let t = new Sn(e), i = await Promise.race([n(), t.promise]);
		t.clearNetworkTimeout();
		let a = await i.json();
		if ("needConfirmation" in a) throw z(e, "account-exists-with-different-credential", a);
		if (i.ok && !("errorMessage" in a)) return a;
		{
			let [t, n] = (i.ok ? a.errorMessage : a.error.message).split(" : ");
			if (t === "FEDERATED_USER_ID_ALREADY_LINKED") throw z(e, "credential-already-in-use", a);
			if (t === "EMAIL_EXISTS") throw z(e, "email-already-in-use", a);
			if (t === "USER_DISABLED") throw z(e, "user-disabled", a);
			let o = r[t] || t.toLowerCase().replace(/[_\s]+/g, "-");
			if (n) throw an(e, o, n);
			P(e, o);
		}
	} catch (t) {
		if (t instanceof v) throw t;
		P(e, "network-request-failed", { message: String(t) });
	}
}
async function bn(e, t, n, r, i = {}) {
	let a = await R(e, t, n, r, i);
	return "mfaPendingCredential" in a && P(e, "multi-factor-auth-required", { _serverResponse: a }), a;
}
async function xn(e, t, n, r) {
	let i = `${t}${n}?${r}`, a = e, o = a.config.emulator ? pn(e.config, i) : `${e.config.apiScheme}://${i}`;
	return gn.includes(n) && (await a._persistenceManagerAvailable, a._getPersistenceType() === "COOKIE") ? a._getPersistence()._getFinalTarget(o).toString() : o;
}
var Sn = class {
	clearNetworkTimeout() {
		clearTimeout(this.timer);
	}
	constructor(e) {
		this.auth = e, this.timer = null, this.promise = new Promise((e, t) => {
			this.timer = setTimeout(() => t(rn(this.auth, "network-request-failed")), _n.get());
		});
	}
};
function z(e, t, n) {
	let r = { appName: e.name };
	n.email && (r.email = n.email), n.phoneNumber && (r.phoneNumber = n.phoneNumber);
	let i = rn(e, t, r);
	return i.customData._tokenResponse = n, i;
}
async function Cn(e, t) {
	return R(e, "POST", "/v1/accounts:delete", t);
}
async function B(e, t) {
	return R(e, "POST", "/v1/accounts:lookup", t);
}
function V(e) {
	if (e) try {
		let t = new Date(Number(e));
		if (!isNaN(t.getTime())) return t.toUTCString();
	} catch {}
}
async function wn(e, t = !1) {
	let n = x(e), r = await n.getIdToken(t), i = En(r);
	F(i && i.exp && i.auth_time && i.iat, n.auth, "internal-error");
	let a = typeof i.firebase == "object" ? i.firebase : void 0, o = a?.sign_in_provider;
	return {
		claims: i,
		token: r,
		authTime: V(Tn(i.auth_time)),
		issuedAtTime: V(Tn(i.iat)),
		expirationTime: V(Tn(i.exp)),
		signInProvider: o || null,
		signInSecondFactor: a?.sign_in_second_factor || null
	};
}
function Tn(e) {
	return Number(e) * 1e3;
}
function En(e) {
	let [t, n, r] = e.split(".");
	if (t === void 0 || n === void 0 || r === void 0) return nn("JWT malformed, contained fewer than 3 sections"), null;
	try {
		let e = s(n);
		return e ? JSON.parse(e) : (nn("Failed to decode base64 JWT payload"), null);
	} catch (e) {
		return nn("Caught error parsing JWT payload as JSON", e?.toString()), null;
	}
}
function Dn(e) {
	let t = En(e);
	return F(t, "internal-error"), F(t.exp !== void 0, "internal-error"), F(t.iat !== void 0, "internal-error"), Number(t.exp) - Number(t.iat);
}
async function On(e, t, n = !1) {
	if (n) return t;
	try {
		return await t;
	} catch (t) {
		throw kn(t) && e.auth.currentUser === e && await e.auth.signOut(), t;
	}
}
function kn(e) {
	return e instanceof v ? e.code === "auth/user-disabled" || e.code === "auth/user-token-expired" : !1;
}
var An = class {
	constructor(e) {
		this.user = e, this.isRunning = !1, this.timerId = null, this.errorBackoff = 3e4;
	}
	_start() {
		this.isRunning || (this.isRunning = !0, this.schedule());
	}
	_stop() {
		this.isRunning && (this.isRunning = !1, this.timerId !== null && clearTimeout(this.timerId));
	}
	getInterval(e) {
		if (e) {
			let e = this.errorBackoff;
			return this.errorBackoff = Math.min(this.errorBackoff * 2, 96e4), e;
		}
		{
			this.errorBackoff = 3e4;
			let e = (this.user.stsTokenManager.expirationTime ?? 0) - Date.now() - 3e5;
			return Math.max(0, e);
		}
	}
	schedule(e = !1) {
		if (!this.isRunning) return;
		let t = this.getInterval(e);
		this.timerId = setTimeout(async () => {
			await this.iteration();
		}, t);
	}
	async iteration() {
		try {
			await this.user.getIdToken(!0);
		} catch (e) {
			e?.code === "auth/network-request-failed" && this.schedule(!0);
			return;
		}
		this.schedule();
	}
}, jn = class {
	constructor(e, t) {
		this.createdAt = e, this.lastLoginAt = t, this._initializeTime();
	}
	_initializeTime() {
		this.lastSignInTime = V(this.lastLoginAt), this.creationTime = V(this.createdAt);
	}
	_copy(e) {
		this.createdAt = e.createdAt, this.lastLoginAt = e.lastLoginAt, this._initializeTime();
	}
	toJSON() {
		return {
			createdAt: this.createdAt,
			lastLoginAt: this.lastLoginAt
		};
	}
};
async function H(e) {
	let t = e.auth, n = await On(e, B(t, { idToken: await e.getIdToken() }));
	F(n?.users.length, t, "internal-error");
	let r = n.users[0];
	e._notifyReloadListener(r);
	let i = r.providerUserInfo?.length ? Pn(r.providerUserInfo) : [], a = Nn(e.providerData, i), o = e.isAnonymous, s = !(e.email && r.passwordHash) && !a?.length, c = o ? s : !1, l = {
		uid: r.localId,
		displayName: r.displayName || null,
		photoURL: r.photoUrl || null,
		email: r.email || null,
		emailVerified: r.emailVerified || !1,
		phoneNumber: r.phoneNumber || null,
		tenantId: r.tenantId || null,
		providerData: a,
		metadata: new jn(r.createdAt, r.lastLoginAt),
		isAnonymous: c
	};
	Object.assign(e, l);
}
async function Mn(e) {
	let t = x(e);
	await H(t), await t.auth._persistUserIfCurrent(t), t.auth._notifyListenersIfCurrent(t);
}
function Nn(e, t) {
	return [...e.filter((e) => !t.some((t) => t.providerId === e.providerId)), ...t];
}
function Pn(e) {
	return e.map(({ providerId: e, ...t }) => ({
		providerId: e,
		uid: t.rawId || "",
		displayName: t.displayName || null,
		email: t.email || null,
		phoneNumber: t.phoneNumber || null,
		photoURL: t.photoUrl || null
	}));
}
async function Fn(e, t) {
	let n = await yn(e, {}, async () => {
		let n = ue({
			grant_type: "refresh_token",
			refresh_token: t
		}).slice(1), { tokenApiHost: r, apiKey: i } = e.config, a = await xn(e, r, "/v1/token", `key=${i}`), o = await e._getAdditionalHeaders();
		o["Content-Type"] = "application/x-www-form-urlencoded";
		let s = {
			method: "POST",
			headers: o,
			body: n
		};
		return e.emulatorConfig && S(e.emulatorConfig.host) && (s.credentials = "include"), mn.fetch()(a, s);
	});
	return {
		accessToken: n.access_token,
		expiresIn: n.expires_in,
		refreshToken: n.refresh_token
	};
}
async function In(e, t) {
	return R(e, "POST", "/v2/accounts:revokeToken", vn(e, t));
}
var Ln = class e {
	constructor() {
		this.refreshToken = null, this.accessToken = null, this.expirationTime = null;
	}
	get isExpired() {
		return !this.expirationTime || Date.now() > this.expirationTime - 3e4;
	}
	updateFromServerResponse(e) {
		F(e.idToken, "internal-error"), F(e.idToken !== void 0, "internal-error"), F(e.refreshToken !== void 0, "internal-error");
		let t = "expiresIn" in e && e.expiresIn !== void 0 ? Number(e.expiresIn) : Dn(e.idToken);
		this.updateTokensAndExpiration(e.idToken, e.refreshToken, t);
	}
	updateFromIdToken(e) {
		F(e.length !== 0, "internal-error");
		let t = Dn(e);
		this.updateTokensAndExpiration(e, null, t);
	}
	async getToken(e, t = !1) {
		return !t && this.accessToken && !this.isExpired ? this.accessToken : (F(this.refreshToken, e, "user-token-expired"), this.refreshToken ? (await this.refresh(e, this.refreshToken), this.accessToken) : null);
	}
	clearRefreshToken() {
		this.refreshToken = null;
	}
	async refresh(e, t) {
		let { accessToken: n, refreshToken: r, expiresIn: i } = await Fn(e, t);
		this.updateTokensAndExpiration(n, r, Number(i));
	}
	updateTokensAndExpiration(e, t, n) {
		this.refreshToken = t || null, this.accessToken = e || null, this.expirationTime = Date.now() + n * 1e3;
	}
	static fromJSON(t, n) {
		let { refreshToken: r, accessToken: i, expirationTime: a } = n, o = new e();
		return r && (F(typeof r == "string", "internal-error", { appName: t }), o.refreshToken = r), i && (F(typeof i == "string", "internal-error", { appName: t }), o.accessToken = i), a && (F(typeof a == "number", "internal-error", { appName: t }), o.expirationTime = a), o;
	}
	toJSON() {
		return {
			refreshToken: this.refreshToken,
			accessToken: this.accessToken,
			expirationTime: this.expirationTime
		};
	}
	_assign(e) {
		this.accessToken = e.accessToken, this.refreshToken = e.refreshToken, this.expirationTime = e.expirationTime;
	}
	_clone() {
		return Object.assign(new e(), this.toJSON());
	}
	_performRefresh() {
		return I("not implemented");
	}
};
function U(e, t) {
	F(typeof e == "string" || e === void 0, "internal-error", { appName: t });
}
var W = class e {
	constructor({ uid: e, auth: t, stsTokenManager: n, ...r }) {
		this.providerId = "firebase", this.proactiveRefresh = new An(this), this.reloadUserInfo = null, this.reloadListener = null, this.uid = e, this.auth = t, this.stsTokenManager = n, this.accessToken = n.accessToken, this.displayName = r.displayName || null, this.email = r.email || null, this.emailVerified = r.emailVerified || !1, this.phoneNumber = r.phoneNumber || null, this.photoURL = r.photoURL || null, this.isAnonymous = r.isAnonymous || !1, this.tenantId = r.tenantId || null, this.providerData = r.providerData ? [...r.providerData] : [], this.metadata = new jn(r.createdAt || void 0, r.lastLoginAt || void 0);
	}
	async getIdToken(e) {
		let t = await On(this, this.stsTokenManager.getToken(this.auth, e));
		return F(t, this.auth, "internal-error"), this.accessToken !== t && (this.accessToken = t, await this.auth._persistUserIfCurrent(this), this.auth._notifyListenersIfCurrent(this)), t;
	}
	getIdTokenResult(e) {
		return wn(this, e);
	}
	reload() {
		return Mn(this);
	}
	_assign(e) {
		this !== e && (F(this.uid === e.uid, this.auth, "internal-error"), this.displayName = e.displayName, this.photoURL = e.photoURL, this.email = e.email, this.emailVerified = e.emailVerified, this.phoneNumber = e.phoneNumber, this.isAnonymous = e.isAnonymous, this.tenantId = e.tenantId, this.providerData = e.providerData.map((e) => ({ ...e })), this.metadata._copy(e.metadata), this.stsTokenManager._assign(e.stsTokenManager));
	}
	_clone(t) {
		let n = new e({
			...this,
			auth: t,
			stsTokenManager: this.stsTokenManager._clone()
		});
		return n.metadata._copy(this.metadata), n;
	}
	_onReload(e) {
		F(!this.reloadListener, this.auth, "internal-error"), this.reloadListener = e, this.reloadUserInfo &&= (this._notifyReloadListener(this.reloadUserInfo), null);
	}
	_notifyReloadListener(e) {
		this.reloadListener ? this.reloadListener(e) : this.reloadUserInfo = e;
	}
	_startProactiveRefresh() {
		this.proactiveRefresh._start();
	}
	_stopProactiveRefresh() {
		this.proactiveRefresh._stop();
	}
	async _updateTokensIfNecessary(e, t = !1) {
		let n = !1;
		e.idToken && e.idToken !== this.stsTokenManager.accessToken && (this.stsTokenManager.updateFromServerResponse(e), n = !0), t && await H(this), await this.auth._persistUserIfCurrent(this), n && this.auth._notifyListenersIfCurrent(this);
	}
	async delete() {
		if (k(this.auth.app)) return Promise.reject(on(this.auth));
		let e = await this.getIdToken();
		return await On(this, Cn(this.auth, { idToken: e })), this.stsTokenManager.clearRefreshToken(), this.auth.signOut();
	}
	toJSON() {
		return {
			uid: this.uid,
			email: this.email || void 0,
			emailVerified: this.emailVerified,
			displayName: this.displayName || void 0,
			isAnonymous: this.isAnonymous,
			photoURL: this.photoURL || void 0,
			phoneNumber: this.phoneNumber || void 0,
			tenantId: this.tenantId || void 0,
			providerData: this.providerData.map((e) => ({ ...e })),
			stsTokenManager: this.stsTokenManager.toJSON(),
			_redirectEventId: this._redirectEventId,
			...this.metadata.toJSON(),
			apiKey: this.auth.config.apiKey,
			appName: this.auth.name
		};
	}
	get refreshToken() {
		return this.stsTokenManager.refreshToken || "";
	}
	static _fromJSON(t, n) {
		let r = n.displayName ?? void 0, i = n.email ?? void 0, a = n.phoneNumber ?? void 0, o = n.photoURL ?? void 0, s = n.tenantId ?? void 0, c = n._redirectEventId ?? void 0, l = n.createdAt ?? void 0, u = n.lastLoginAt ?? void 0, { uid: d, emailVerified: f, isAnonymous: p, providerData: m, stsTokenManager: h } = n;
		F(d && h, t, "internal-error");
		let ee = Ln.fromJSON(this.name, h);
		F(typeof d == "string", t, "internal-error"), U(r, t.name), U(i, t.name), F(typeof f == "boolean", t, "internal-error"), F(typeof p == "boolean", t, "internal-error"), U(a, t.name), U(o, t.name), U(s, t.name), U(c, t.name), U(l, t.name), U(u, t.name);
		let g = new e({
			uid: d,
			auth: t,
			email: i,
			emailVerified: f,
			displayName: r,
			isAnonymous: p,
			photoURL: o,
			phoneNumber: a,
			tenantId: s,
			stsTokenManager: ee,
			createdAt: l,
			lastLoginAt: u
		});
		return m && Array.isArray(m) && (g.providerData = m.map((e) => ({ ...e }))), c && (g._redirectEventId = c), g;
	}
	static async _fromIdTokenResponse(t, n, r = !1) {
		let i = new Ln();
		i.updateFromServerResponse(n);
		let a = new e({
			uid: n.localId,
			auth: t,
			stsTokenManager: i,
			isAnonymous: r
		});
		return await H(a), a;
	}
	static async _fromGetAccountInfoResponse(t, n, r) {
		let i = n.users[0];
		F(i.localId !== void 0, "internal-error");
		let a = i.providerUserInfo === void 0 ? [] : Pn(i.providerUserInfo), o = !(i.email && i.passwordHash) && !a?.length, s = new Ln();
		s.updateFromIdToken(r);
		let c = new e({
			uid: i.localId,
			auth: t,
			stsTokenManager: s,
			isAnonymous: o
		}), l = {
			uid: i.localId,
			displayName: i.displayName || null,
			photoURL: i.photoUrl || null,
			email: i.email || null,
			emailVerified: i.emailVerified || !1,
			phoneNumber: i.phoneNumber || null,
			tenantId: i.tenantId || null,
			providerData: a,
			metadata: new jn(i.createdAt, i.lastLoginAt),
			isAnonymous: !(i.email && i.passwordHash) && !a?.length
		};
		return Object.assign(c, l), c;
	}
}, Rn = /* @__PURE__ */ new Map();
function G(e) {
	L(e instanceof Function, "Expected a class definition");
	let t = Rn.get(e);
	return t ? (L(t instanceof e, "Instance stored in cache mismatched with class"), t) : (t = new e(), Rn.set(e, t), t);
}
var zn = class {
	constructor() {
		this.type = "NONE", this.storage = {};
	}
	async _isAvailable() {
		return !0;
	}
	async _set(e, t) {
		this.storage[e] = t;
	}
	async _get(e) {
		let t = this.storage[e];
		return t === void 0 ? null : t;
	}
	async _remove(e) {
		delete this.storage[e];
	}
	_addListener(e, t) {}
	_removeListener(e, t) {}
};
zn.type = "NONE";
var Bn = zn;
function Vn(e, t, n) {
	return `firebase:${e}:${t}:${n}`;
}
var Hn = class e {
	constructor(e, t, n) {
		this.persistence = e, this.auth = t, this.userKey = n;
		let { config: r, name: i } = this.auth;
		this.fullUserKey = Vn(this.userKey, r.apiKey, i), this.fullPersistenceKey = Vn("persistence", r.apiKey, i), this.boundEventHandler = t._onStorageEvent.bind(t);
		try {
			this.persistence._addListener(this.fullUserKey, this.boundEventHandler);
		} catch {}
	}
	setCurrentUser(e) {
		return this.persistence._set(this.fullUserKey, e.toJSON());
	}
	async getCurrentUser() {
		let e = await this.persistence._get(this.fullUserKey);
		if (!e) return null;
		if (typeof e == "string") {
			let t = await B(this.auth, { idToken: e }).catch(() => void 0);
			return t ? W._fromGetAccountInfoResponse(this.auth, t, e) : null;
		}
		return W._fromJSON(this.auth, e);
	}
	removeCurrentUser() {
		return this.persistence._remove(this.fullUserKey);
	}
	savePersistenceForRedirect() {
		return this.persistence._set(this.fullPersistenceKey, this.persistence.type);
	}
	async setPersistence(e) {
		if (this.persistence === e) return;
		let t = await this.getCurrentUser();
		if (await this.removeCurrentUser(), this.persistence = e, t) return this.setCurrentUser(t);
	}
	delete() {
		try {
			this.persistence._removeListener(this.fullUserKey, this.boundEventHandler);
		} catch {}
	}
	static async create(t, n, r = "authUser") {
		if (!n.length) return new e(G(Bn), t, r);
		let i = (await Promise.all(n.map(async (e) => {
			try {
				if (await e._isAvailable()) return e;
			} catch {
				return;
			}
		}))).filter((e) => e), a = i[0] || G(Bn), o = Vn(r, t.config.apiKey, t.name), s = null;
		for (let e of n) try {
			let n = await e._get(o);
			if (n) {
				let r;
				if (typeof n == "string") {
					let e = await B(t, { idToken: n }).catch(() => void 0);
					if (!e) break;
					r = await W._fromGetAccountInfoResponse(t, e, n);
				} else r = W._fromJSON(t, n);
				e !== a && (s = r), a = e;
				break;
			}
		} catch {}
		let c = i.filter((e) => e._shouldAllowMigration);
		return !a._shouldAllowMigration || !c.length || (a = c[0], s && await a._set(o, s.toJSON()), await Promise.all(n.map(async (e) => {
			if (e !== a) try {
				await e._remove(o);
			} catch {}
		}))), new e(a, t, r);
	}
};
function Un(e) {
	let t = e.toLowerCase();
	if (t.includes("opera/") || t.includes("opr/") || t.includes("opios/")) return "Opera";
	if (qn(t)) return "IEMobile";
	if (t.includes("msie") || t.includes("trident/")) return "IE";
	if (t.includes("edge/")) return "Edge";
	if (Wn(t)) return "Firefox";
	if (t.includes("silk/")) return "Silk";
	if (Yn(t)) return "Blackberry";
	if (Xn(t)) return "Webos";
	if (Gn(t)) return "Safari";
	if ((t.includes("chrome/") || Kn(t)) && !t.includes("edge/")) return "Chrome";
	if (Jn(t)) return "Android";
	{
		let t = e.match(/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/);
		if (t?.length === 2) return t[1];
	}
	return "Other";
}
function Wn(e = _()) {
	return /firefox\//i.test(e);
}
function Gn(e = _()) {
	let t = e.toLowerCase();
	return t.includes("safari/") && !t.includes("chrome/") && !t.includes("crios/") && !t.includes("android");
}
function Kn(e = _()) {
	return /crios\//i.test(e);
}
function qn(e = _()) {
	return /iemobile/i.test(e);
}
function Jn(e = _()) {
	return /android/i.test(e);
}
function Yn(e = _()) {
	return /blackberry/i.test(e);
}
function Xn(e = _()) {
	return /webos/i.test(e);
}
function Zn(e, t = []) {
	let n;
	switch (e) {
		case "Browser":
			n = Un(_());
			break;
		case "Worker":
			n = `${Un(_())}-${e}`;
			break;
		default: n = e;
	}
	let r = t.length ? t.join(",") : "FirebaseCore-web";
	return `${n}/JsCore/${j}/${r}`;
}
var Qn = class {
	constructor(e) {
		this.auth = e, this.queue = [];
	}
	pushCallback(e, t) {
		let n = (t) => new Promise((n, r) => {
			try {
				n(e(t));
			} catch (e) {
				r(e);
			}
		});
		n.onAbort = t, this.queue.push(n);
		let r = this.queue.length - 1;
		return () => {
			this.queue[r] = () => Promise.resolve();
		};
	}
	async runMiddleware(e) {
		if (this.auth.currentUser === e) return;
		let t = [];
		try {
			for (let n of this.queue) await n(e), n.onAbort && t.push(n.onAbort);
		} catch (e) {
			t.reverse();
			for (let e of t) try {
				e();
			} catch {}
			throw this.auth._errorFactory.create("login-blocked", { originalMessage: e?.message });
		}
	}
};
async function $n(e, t = {}) {
	return R(e, "GET", "/v2/passwordPolicy", vn(e, t));
}
var er = 6, tr = class {
	constructor(e) {
		let t = e.customStrengthOptions;
		this.customStrengthOptions = {}, this.customStrengthOptions.minPasswordLength = t.minPasswordLength ?? er, t.maxPasswordLength && (this.customStrengthOptions.maxPasswordLength = t.maxPasswordLength), t.containsLowercaseCharacter !== void 0 && (this.customStrengthOptions.containsLowercaseLetter = t.containsLowercaseCharacter), t.containsUppercaseCharacter !== void 0 && (this.customStrengthOptions.containsUppercaseLetter = t.containsUppercaseCharacter), t.containsNumericCharacter !== void 0 && (this.customStrengthOptions.containsNumericCharacter = t.containsNumericCharacter), t.containsNonAlphanumericCharacter !== void 0 && (this.customStrengthOptions.containsNonAlphanumericCharacter = t.containsNonAlphanumericCharacter), this.enforcementState = e.enforcementState, this.enforcementState === "ENFORCEMENT_STATE_UNSPECIFIED" && (this.enforcementState = "OFF"), this.allowedNonAlphanumericCharacters = e.allowedNonAlphanumericCharacters?.join("") ?? "", this.forceUpgradeOnSignin = e.forceUpgradeOnSignin ?? !1, this.schemaVersion = e.schemaVersion;
	}
	validatePassword(e) {
		let t = {
			isValid: !0,
			passwordPolicy: this
		};
		return this.validatePasswordLengthOptions(e, t), this.validatePasswordCharacterOptions(e, t), t.isValid &&= t.meetsMinPasswordLength ?? !0, t.isValid &&= t.meetsMaxPasswordLength ?? !0, t.isValid &&= t.containsLowercaseLetter ?? !0, t.isValid &&= t.containsUppercaseLetter ?? !0, t.isValid &&= t.containsNumericCharacter ?? !0, t.isValid &&= t.containsNonAlphanumericCharacter ?? !0, t;
	}
	validatePasswordLengthOptions(e, t) {
		let n = this.customStrengthOptions.minPasswordLength, r = this.customStrengthOptions.maxPasswordLength;
		n && (t.meetsMinPasswordLength = e.length >= n), r && (t.meetsMaxPasswordLength = e.length <= r);
	}
	validatePasswordCharacterOptions(e, t) {
		this.updatePasswordCharacterOptionsStatuses(t, !1, !1, !1, !1);
		let n;
		for (let r = 0; r < e.length; r++) n = e.charAt(r), this.updatePasswordCharacterOptionsStatuses(t, n >= "a" && n <= "z", n >= "A" && n <= "Z", n >= "0" && n <= "9", this.allowedNonAlphanumericCharacters.includes(n));
	}
	updatePasswordCharacterOptionsStatuses(e, t, n, r, i) {
		this.customStrengthOptions.containsLowercaseLetter && (e.containsLowercaseLetter ||= t), this.customStrengthOptions.containsUppercaseLetter && (e.containsUppercaseLetter ||= n), this.customStrengthOptions.containsNumericCharacter && (e.containsNumericCharacter ||= r), this.customStrengthOptions.containsNonAlphanumericCharacter && (e.containsNonAlphanumericCharacter ||= i);
	}
}, nr = class {
	constructor(e, t, n, r) {
		this.app = e, this.heartbeatServiceProvider = t, this.appCheckServiceProvider = n, this.config = r, this.currentUser = null, this.emulatorConfig = null, this.operations = Promise.resolve(), this.authStateSubscription = new ir(this), this.idTokenSubscription = new ir(this), this.beforeStateQueue = new Qn(this), this.redirectUser = null, this.isProactiveRefreshEnabled = !1, this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION = 1, this._canInitEmulator = !0, this._isInitialized = !1, this._deleted = !1, this._initializationPromise = null, this._popupRedirectResolver = null, this._errorFactory = $t, this._agentRecaptchaConfig = null, this._tenantRecaptchaConfigs = {}, this._projectPasswordPolicy = null, this._tenantPasswordPolicies = {}, this._resolvePersistenceManagerAvailable = void 0, this.lastNotifiedUid = void 0, this.languageCode = null, this.tenantId = null, this.settings = { appVerificationDisabledForTesting: !1 }, this.frameworks = [], this.name = e.name, this.clientVersion = r.sdkClientVersion, this._persistenceManagerAvailable = new Promise((e) => this._resolvePersistenceManagerAvailable = e);
	}
	_initializeWithPersistence(e, t) {
		return t && (this._popupRedirectResolver = G(t)), this._initializationPromise = this.queue(async () => {
			if (!this._deleted) {
				try {
					this.persistenceManager = await Hn.create(this, e);
				} catch (e) {
					tn(`Failed to initialize persistence: ${e}`), this.persistenceManager = await Hn.create(this, []);
				} finally {
					this._resolvePersistenceManagerAvailable?.();
				}
				if (!this._deleted) {
					if (this._popupRedirectResolver?._shouldInitProactively) try {
						await this._popupRedirectResolver._initialize(this);
					} catch {}
					try {
						await this.initializeCurrentUser(t);
					} catch (e) {
						tn(`Failed to initialize current user: ${e}`), await this.directlySetCurrentUser(null).catch(() => {});
					}
					this.lastNotifiedUid = this.currentUser?.uid || null, !this._deleted && (this._isInitialized = !0);
				}
			}
		}), this._initializationPromise;
	}
	async _onStorageEvent() {
		if (this._deleted) return;
		let e = await this.assertedPersistence.getCurrentUser();
		(this.currentUser || e) && (this.currentUser && e && this.currentUser.uid === e.uid ? (this._currentUser._assign(e), await this.currentUser.getIdToken()) : await this._updateCurrentUser(e, !0));
	}
	async initializeCurrentUserFromIdToken(e) {
		try {
			let t = await B(this, { idToken: e }), n = await W._fromGetAccountInfoResponse(this, t, e);
			await this.directlySetCurrentUser(n);
		} catch (e) {
			console.warn("FirebaseServerApp could not login user with provided authIdToken: ", e), await this.directlySetCurrentUser(null);
		}
	}
	async initializeCurrentUser(e) {
		if (k(this.app)) {
			let e = this.app.settings.authIdToken;
			return e ? new Promise((t) => {
				setTimeout(() => this.initializeCurrentUserFromIdToken(e).then(t, t));
			}) : this.directlySetCurrentUser(null);
		}
		let t = await this.assertedPersistence.getCurrentUser(), n = t, r = !1;
		if (e && this.config.authDomain) {
			await this.getOrInitRedirectPersistenceManager();
			let t = this.redirectUser?._redirectEventId, i = n?._redirectEventId, a = await this.tryRedirectSignIn(e);
			(!t || t === i) && a?.user && (n = a.user, r = !0);
		}
		if (!n) return this.directlySetCurrentUser(null);
		if (!n._redirectEventId) {
			if (r) try {
				await this.beforeStateQueue.runMiddleware(n);
			} catch (e) {
				n = t, this._popupRedirectResolver._overrideRedirectResult(this, () => Promise.reject(e));
			}
			return n ? this.reloadAndSetCurrentUserOrClear(n) : this.directlySetCurrentUser(null);
		}
		return F(this._popupRedirectResolver, this, "argument-error"), await this.getOrInitRedirectPersistenceManager(), this.redirectUser && this.redirectUser._redirectEventId === n._redirectEventId ? this.directlySetCurrentUser(n) : this.reloadAndSetCurrentUserOrClear(n);
	}
	async tryRedirectSignIn(e) {
		let t = null;
		try {
			t = await this._popupRedirectResolver._completeRedirectFn(this, e, !0);
		} catch {
			await this._setRedirectUser(null);
		}
		return t;
	}
	async reloadAndSetCurrentUserOrClear(e) {
		try {
			await H(e);
		} catch (e) {
			if (kn(e)) return this.directlySetCurrentUser(null);
		}
		return this.directlySetCurrentUser(e);
	}
	useDeviceLanguage() {
		this.languageCode = dn();
	}
	async _delete() {
		this._deleted = !0;
	}
	async updateCurrentUser(e) {
		if (k(this.app)) return Promise.reject(on(this));
		let t = e ? x(e) : null;
		return t && F(t.auth.config.apiKey === this.config.apiKey, this, "invalid-user-token"), this._updateCurrentUser(t && t._clone(this));
	}
	async _updateCurrentUser(e, t = !1) {
		if (!this._deleted) return e && F(this.tenantId === e.tenantId, this, "tenant-id-mismatch"), t || await this.beforeStateQueue.runMiddleware(e), this.queue(async () => {
			await this.directlySetCurrentUser(e), this.notifyAuthListeners();
		});
	}
	async signOut() {
		return k(this.app) ? Promise.reject(on(this)) : (await this.beforeStateQueue.runMiddleware(null), (this.redirectPersistenceManager || this._popupRedirectResolver) && await this._setRedirectUser(null), this._updateCurrentUser(null, !0));
	}
	setPersistence(e) {
		return k(this.app) ? Promise.reject(on(this)) : this.queue(async () => {
			await this.assertedPersistence.setPersistence(G(e));
		});
	}
	_getRecaptchaConfig() {
		return this.tenantId == null ? this._agentRecaptchaConfig : this._tenantRecaptchaConfigs[this.tenantId];
	}
	async validatePassword(e) {
		this._getPasswordPolicyInternal() || await this._updatePasswordPolicy();
		let t = this._getPasswordPolicyInternal();
		return t.schemaVersion === this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION ? t.validatePassword(e) : Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version", {}));
	}
	_getPasswordPolicyInternal() {
		return this.tenantId === null ? this._projectPasswordPolicy : this._tenantPasswordPolicies[this.tenantId];
	}
	async _updatePasswordPolicy() {
		let e = new tr(await $n(this));
		this.tenantId === null ? this._projectPasswordPolicy = e : this._tenantPasswordPolicies[this.tenantId] = e;
	}
	_getPersistenceType() {
		return this.assertedPersistence.persistence.type;
	}
	_getPersistence() {
		return this.assertedPersistence.persistence;
	}
	_updateErrorMap(e) {
		this._errorFactory = new y("auth", "Firebase", e());
	}
	onAuthStateChanged(e, t, n) {
		return this.registerStateListener(this.authStateSubscription, e, t, n);
	}
	beforeAuthStateChanged(e, t) {
		return this.beforeStateQueue.pushCallback(e, t);
	}
	onIdTokenChanged(e, t, n) {
		return this.registerStateListener(this.idTokenSubscription, e, t, n);
	}
	authStateReady() {
		return new Promise((e, t) => {
			if (this.currentUser) e();
			else {
				let n = this.onAuthStateChanged(() => {
					n(), e();
				}, t);
			}
		});
	}
	async revokeAccessToken(e) {
		if (this.currentUser) {
			let t = {
				providerId: "apple.com",
				tokenType: "ACCESS_TOKEN",
				token: e,
				idToken: await this.currentUser.getIdToken()
			};
			this.tenantId != null && (t.tenantId = this.tenantId), await In(this, t);
		}
	}
	toJSON() {
		return {
			apiKey: this.config.apiKey,
			authDomain: this.config.authDomain,
			appName: this.name,
			currentUser: this._currentUser?.toJSON()
		};
	}
	async _setRedirectUser(e, t) {
		let n = await this.getOrInitRedirectPersistenceManager(t);
		return e === null ? n.removeCurrentUser() : n.setCurrentUser(e);
	}
	async getOrInitRedirectPersistenceManager(e) {
		if (!this.redirectPersistenceManager) {
			let t = e && G(e) || this._popupRedirectResolver;
			F(t, this, "argument-error"), this.redirectPersistenceManager = await Hn.create(this, [G(t._redirectPersistence)], "redirectUser"), this.redirectUser = await this.redirectPersistenceManager.getCurrentUser();
		}
		return this.redirectPersistenceManager;
	}
	async _redirectUserForId(e) {
		return this._isInitialized && await this.queue(async () => {}), this._currentUser?._redirectEventId === e ? this._currentUser : this.redirectUser?._redirectEventId === e ? this.redirectUser : null;
	}
	async _persistUserIfCurrent(e) {
		if (e === this.currentUser) return this.queue(async () => this.directlySetCurrentUser(e));
	}
	_notifyListenersIfCurrent(e) {
		e === this.currentUser && this.notifyAuthListeners();
	}
	_key() {
		return `${this.config.authDomain}:${this.config.apiKey}:${this.name}`;
	}
	_startProactiveRefresh() {
		this.isProactiveRefreshEnabled = !0, this.currentUser && this._currentUser._startProactiveRefresh();
	}
	_stopProactiveRefresh() {
		this.isProactiveRefreshEnabled = !1, this.currentUser && this._currentUser._stopProactiveRefresh();
	}
	get _currentUser() {
		return this.currentUser;
	}
	notifyAuthListeners() {
		if (!this._isInitialized) return;
		this.idTokenSubscription.next(this.currentUser);
		let e = this.currentUser?.uid ?? null;
		this.lastNotifiedUid !== e && (this.lastNotifiedUid = e, this.authStateSubscription.next(this.currentUser));
	}
	registerStateListener(e, t, n, r) {
		if (this._deleted) return () => {};
		let i = typeof t == "function" ? t : t.next.bind(t), a = !1, o = this._isInitialized ? Promise.resolve() : this._initializationPromise;
		if (F(o, this, "internal-error"), o.then(() => {
			a || i(this.currentUser);
		}).catch((e) => {
			if (!a) {
				if (typeof t != "function" && t.error) t.error(e);
				else if (n) n(e);
				else throw e;
			}
		}), typeof t == "function") {
			let i = e.addObserver(t, n, r);
			return () => {
				a = !0, i();
			};
		}
		{
			let n = e.addObserver(t);
			return () => {
				a = !0, n();
			};
		}
	}
	async directlySetCurrentUser(e) {
		if (this.currentUser && this.currentUser !== e && this._currentUser._stopProactiveRefresh(), e && this.isProactiveRefreshEnabled && e._startProactiveRefresh(), this.currentUser = e, this.persistenceManager) try {
			e ? await this.persistenceManager.setCurrentUser(e) : await this.persistenceManager.removeCurrentUser();
		} catch (e) {
			let t = e?.message || String(e), n = an(this, "internal-error", `An internal AuthError has occurred: ${t}`);
			throw n.customData = { originalError: e }, n;
		}
	}
	queue(e) {
		return this.operations = this.operations.then(e, e), this.operations;
	}
	get assertedPersistence() {
		return F(this.persistenceManager, this, "internal-error"), this.persistenceManager;
	}
	_logFramework(e) {
		e && !this.frameworks.includes(e) && (this.frameworks.push(e), this.frameworks.sort(), this.clientVersion = Zn(this.config.clientPlatform, this._getFrameworks()));
	}
	_getFrameworks() {
		return this.frameworks;
	}
	async _getAdditionalHeaders() {
		let e = { "X-Client-Version": this.clientVersion };
		this.app.options.appId && (e["X-Firebase-gmpid"] = this.app.options.appId);
		let t = await this.heartbeatServiceProvider.getImmediate({ optional: !0 })?.getHeartbeatsHeader();
		t && (e["X-Firebase-Client"] = t);
		let n = await this._getAppCheckToken();
		return n && (e["X-Firebase-AppCheck"] = n), e;
	}
	async _getAppCheckToken() {
		if (k(this.app) && this.app.settings.appCheckToken) return this.app.settings.appCheckToken;
		let e = await this.appCheckServiceProvider.getImmediate({ optional: !0 })?.getToken();
		return e?.error && tn(`Error while retrieving App Check token: ${e.error}`), e?.token;
	}
};
function rr(e) {
	return x(e);
}
var ir = class {
	constructor(e) {
		this.auth = e, this.observer = null, this.addObserver = de((e) => this.observer = e);
	}
	get next() {
		return F(this.observer, this.auth, "internal-error"), this.observer.next.bind(this.observer);
	}
};
function ar(e, t) {
	let n = jt(e, "auth");
	if (n.isInitialized()) {
		let e = n.getImmediate();
		if (b(n.getOptions(), t ?? {})) return e;
		P(e, "already-initialized");
	}
	return n.initialize({ options: t });
}
function or(e, t) {
	let n = t?.persistence || [], r = (Array.isArray(n) ? n : [n]).map(G);
	t?.errorMap && e._updateErrorMap(t.errorMap), e._initializeWithPersistence(r, t?.popupRedirectResolver);
}
function sr(e, t, n) {
	let r = rr(e);
	F(/^https?:\/\//.test(t), r, "invalid-emulator-scheme");
	let i = !!n?.disableWarnings, a = cr(t), { host: o, port: s } = lr(t), c = s === null ? "" : `:${s}`, l = { url: `${a}//${o}${c}/` }, u = Object.freeze({
		host: o,
		port: s,
		protocol: a.replace(":", ""),
		options: Object.freeze({ disableWarnings: i })
	});
	r._canInitEmulator ? (r.config.emulator = l, r.emulatorConfig = u, r.settings.appVerificationDisabledForTesting = !0, S(o) ? he(`${a}//${o}${c}`) : i || dr()) : (F(r.config.emulator && r.emulatorConfig, r, "emulator-config-failed"), F(b(l, r.config.emulator) && b(u, r.emulatorConfig), r, "emulator-config-failed"));
}
function cr(e) {
	let t = e.indexOf(":");
	return t < 0 ? "" : e.substr(0, t + 1);
}
function lr(e) {
	let t = cr(e), n = /(\/\/)?([^?#/]+)/.exec(e.substr(t.length));
	if (!n) return {
		host: "",
		port: null
	};
	let r = n[2].split("@").pop() || "", i = /^(\[[^\]]+\])(:|$)/.exec(r);
	if (i) {
		let e = i[1];
		return {
			host: e,
			port: ur(r.substr(e.length + 1))
		};
	}
	{
		let [e, t] = r.split(":");
		return {
			host: e,
			port: ur(t)
		};
	}
}
function ur(e) {
	if (!e) return null;
	let t = Number(e);
	return isNaN(t) ? null : t;
}
function dr() {
	function e() {
		let e = document.createElement("p"), t = e.style;
		e.innerText = "Running in emulator mode. Do not use with production credentials.", t.position = "fixed", t.width = "100%", t.backgroundColor = "#ffffff", t.border = ".1em solid #000000", t.color = "#b50000", t.bottom = "0px", t.left = "0px", t.margin = "0px", t.zIndex = "10000", t.textAlign = "center", e.classList.add("firebase-emulator-warning"), document.body.appendChild(e);
	}
	typeof console < "u" && typeof console.info == "function" && console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."), typeof window < "u" && typeof document < "u" && (document.readyState === "loading" ? window.addEventListener("DOMContentLoaded", e) : e());
}
var fr = class {
	constructor(e, t) {
		this.providerId = e, this.signInMethod = t;
	}
	toJSON() {
		return I("not implemented");
	}
	_getIdTokenResponse(e) {
		return I("not implemented");
	}
	_linkToIdToken(e, t) {
		return I("not implemented");
	}
	_getReauthenticationResolver(e) {
		return I("not implemented");
	}
};
async function pr(e, t) {
	return bn(e, "POST", "/v1/accounts:signInWithIdp", vn(e, t));
}
var mr = "http://localhost", hr = class e extends fr {
	constructor() {
		super(...arguments), this.pendingToken = null;
	}
	static _fromParams(t) {
		let n = new e(t.providerId, t.signInMethod);
		return t.idToken || t.accessToken ? (t.idToken && (n.idToken = t.idToken), t.accessToken && (n.accessToken = t.accessToken), t.nonce && !t.pendingToken && (n.nonce = t.nonce), t.pendingToken && (n.pendingToken = t.pendingToken)) : t.oauthToken && t.oauthTokenSecret ? (n.accessToken = t.oauthToken, n.secret = t.oauthTokenSecret) : P("argument-error"), n;
	}
	toJSON() {
		return {
			idToken: this.idToken,
			accessToken: this.accessToken,
			secret: this.secret,
			nonce: this.nonce,
			pendingToken: this.pendingToken,
			providerId: this.providerId,
			signInMethod: this.signInMethod
		};
	}
	static fromJSON(t) {
		let { providerId: n, signInMethod: r, ...i } = typeof t == "string" ? JSON.parse(t) : t;
		if (!n || !r) return null;
		let a = new e(n, r);
		return a.idToken = i.idToken || void 0, a.accessToken = i.accessToken || void 0, a.secret = i.secret, a.nonce = i.nonce, a.pendingToken = i.pendingToken || null, a;
	}
	_getIdTokenResponse(e) {
		return pr(e, this.buildRequest());
	}
	_linkToIdToken(e, t) {
		let n = this.buildRequest();
		return n.idToken = t, pr(e, n);
	}
	_getReauthenticationResolver(e) {
		let t = this.buildRequest();
		return t.autoCreate = !1, pr(e, t);
	}
	buildRequest() {
		let e = {
			requestUri: mr,
			returnSecureToken: !0
		};
		if (this.pendingToken) e.pendingToken = this.pendingToken;
		else {
			let t = {};
			this.idToken && (t.id_token = this.idToken), this.accessToken && (t.access_token = this.accessToken), this.secret && (t.oauth_token_secret = this.secret), t.providerId = this.providerId, this.nonce && !this.pendingToken && (t.nonce = this.nonce), e.postBody = ue(t);
		}
		return e;
	}
}, gr = class {
	constructor(e) {
		this.providerId = e, this.defaultLanguageCode = null, this.customParameters = {};
	}
	setDefaultLanguage(e) {
		this.defaultLanguageCode = e;
	}
	setCustomParameters(e) {
		return this.customParameters = e, this;
	}
	getCustomParameters() {
		return this.customParameters;
	}
}, _r = class extends gr {
	constructor() {
		super(...arguments), this.scopes = [];
	}
	addScope(e) {
		return this.scopes.includes(e) || this.scopes.push(e), this;
	}
	getScopes() {
		return [...this.scopes];
	}
}, vr = class e extends _r {
	constructor() {
		super("facebook.com");
	}
	static credential(t) {
		return hr._fromParams({
			providerId: e.PROVIDER_ID,
			signInMethod: e.FACEBOOK_SIGN_IN_METHOD,
			accessToken: t
		});
	}
	static credentialFromResult(t) {
		return e.credentialFromTaggedObject(t);
	}
	static credentialFromError(t) {
		return e.credentialFromTaggedObject(t.customData || {});
	}
	static credentialFromTaggedObject({ _tokenResponse: t }) {
		if (!t || !("oauthAccessToken" in t) || !t.oauthAccessToken) return null;
		try {
			return e.credential(t.oauthAccessToken);
		} catch {
			return null;
		}
	}
};
vr.FACEBOOK_SIGN_IN_METHOD = "facebook.com", vr.PROVIDER_ID = "facebook.com";
var yr = class e extends _r {
	constructor() {
		super("google.com"), this.addScope("profile");
	}
	static credential(t, n) {
		return hr._fromParams({
			providerId: e.PROVIDER_ID,
			signInMethod: e.GOOGLE_SIGN_IN_METHOD,
			idToken: t,
			accessToken: n
		});
	}
	static credentialFromResult(t) {
		return e.credentialFromTaggedObject(t);
	}
	static credentialFromError(t) {
		return e.credentialFromTaggedObject(t.customData || {});
	}
	static credentialFromTaggedObject({ _tokenResponse: t }) {
		if (!t) return null;
		let { oauthIdToken: n, oauthAccessToken: r } = t;
		if (!n && !r) return null;
		try {
			return e.credential(n, r);
		} catch {
			return null;
		}
	}
};
yr.GOOGLE_SIGN_IN_METHOD = "google.com", yr.PROVIDER_ID = "google.com";
var br = class e extends _r {
	constructor() {
		super("github.com");
	}
	static credential(t) {
		return hr._fromParams({
			providerId: e.PROVIDER_ID,
			signInMethod: e.GITHUB_SIGN_IN_METHOD,
			accessToken: t
		});
	}
	static credentialFromResult(t) {
		return e.credentialFromTaggedObject(t);
	}
	static credentialFromError(t) {
		return e.credentialFromTaggedObject(t.customData || {});
	}
	static credentialFromTaggedObject({ _tokenResponse: t }) {
		if (!t || !("oauthAccessToken" in t) || !t.oauthAccessToken) return null;
		try {
			return e.credential(t.oauthAccessToken);
		} catch {
			return null;
		}
	}
};
br.GITHUB_SIGN_IN_METHOD = "github.com", br.PROVIDER_ID = "github.com";
var xr = class e extends _r {
	constructor() {
		super("twitter.com");
	}
	static credential(t, n) {
		return hr._fromParams({
			providerId: e.PROVIDER_ID,
			signInMethod: e.TWITTER_SIGN_IN_METHOD,
			oauthToken: t,
			oauthTokenSecret: n
		});
	}
	static credentialFromResult(t) {
		return e.credentialFromTaggedObject(t);
	}
	static credentialFromError(t) {
		return e.credentialFromTaggedObject(t.customData || {});
	}
	static credentialFromTaggedObject({ _tokenResponse: t }) {
		if (!t) return null;
		let { oauthAccessToken: n, oauthTokenSecret: r } = t;
		if (!n || !r) return null;
		try {
			return e.credential(n, r);
		} catch {
			return null;
		}
	}
};
xr.TWITTER_SIGN_IN_METHOD = "twitter.com", xr.PROVIDER_ID = "twitter.com";
function Sr(e, t, n, r) {
	return x(e).onAuthStateChanged(t, n, r);
}
var Cr = "__sak";
function wr(e) {
	return Promise.all(e.map(async (e) => {
		try {
			return {
				fulfilled: !0,
				value: await e
			};
		} catch (e) {
			return {
				fulfilled: !1,
				reason: e
			};
		}
	}));
}
var Tr = class e {
	constructor(e) {
		this.eventTarget = e, this.handlersMap = {}, this.boundEventHandler = this.handleEvent.bind(this);
	}
	static _getInstance(t) {
		let n = this.receivers.find((e) => e.isListeningto(t));
		if (n) return n;
		let r = new e(t);
		return this.receivers.push(r), r;
	}
	isListeningto(e) {
		return this.eventTarget === e;
	}
	async handleEvent(e) {
		let t = e, { eventId: n, eventType: r, data: i } = t.data, a = this.handlersMap[r];
		if (!a?.size) return;
		t.ports[0].postMessage({
			status: "ack",
			eventId: n,
			eventType: r
		});
		let o = await wr(Array.from(a).map(async (e) => e(t.origin, i)));
		t.ports[0].postMessage({
			status: "done",
			eventId: n,
			eventType: r,
			response: o
		});
	}
	_subscribe(e, t) {
		Object.keys(this.handlersMap).length === 0 && this.eventTarget.addEventListener("message", this.boundEventHandler), this.handlersMap[e] || (this.handlersMap[e] = /* @__PURE__ */ new Set()), this.handlersMap[e].add(t);
	}
	_unsubscribe(e, t) {
		this.handlersMap[e] && t && this.handlersMap[e].delete(t), t && this.handlersMap[e].size !== 0 || delete this.handlersMap[e], Object.keys(this.handlersMap).length === 0 && this.eventTarget.removeEventListener("message", this.boundEventHandler);
	}
};
Tr.receivers = [];
function Er(e = "", t = 10) {
	let n = "";
	for (let e = 0; e < t; e++) n += Math.floor(Math.random() * 10);
	return e + n;
}
var Dr = class {
	constructor(e) {
		this.target = e, this.handlers = /* @__PURE__ */ new Set();
	}
	removeMessageHandler(e) {
		e.messageChannel && (e.messageChannel.port1.removeEventListener("message", e.onMessage), e.messageChannel.port1.close()), this.handlers.delete(e);
	}
	async _send(e, t, n = 50) {
		let r = typeof MessageChannel < "u" ? new MessageChannel() : null;
		if (!r) throw Error("connection_unavailable");
		let i, a;
		return new Promise((o, s) => {
			let c = Er("", 20);
			r.port1.start();
			let l = setTimeout(() => {
				s(/* @__PURE__ */ Error("unsupported_event"));
			}, n);
			a = {
				messageChannel: r,
				onMessage(e) {
					let t = e;
					if (t.data.eventId === c) switch (t.data.status) {
						case "ack":
							clearTimeout(l), i = setTimeout(() => {
								s(/* @__PURE__ */ Error("timeout"));
							}, 3e3);
							break;
						case "done":
							clearTimeout(i), o(t.data.response);
							break;
						default: clearTimeout(l), clearTimeout(i), s(/* @__PURE__ */ Error("invalid_response"));
					}
				}
			}, this.handlers.add(a), r.port1.addEventListener("message", a.onMessage), this.target.postMessage({
				eventType: e,
				eventId: c,
				data: t
			}, [r.port2]);
		}).finally(() => {
			a && this.removeMessageHandler(a);
		});
	}
};
function Or() {
	return window;
}
function kr() {
	return Or().WorkerGlobalScope !== void 0 && typeof Or().importScripts == "function";
}
async function Ar() {
	if (!navigator?.serviceWorker) return null;
	try {
		return (await navigator.serviceWorker.ready).active;
	} catch {
		return null;
	}
}
function jr() {
	return navigator?.serviceWorker?.controller || null;
}
function Mr() {
	return kr() ? self : null;
}
var Nr = "firebaseLocalStorageDb", Pr = 1, Fr = "firebaseLocalStorage", Ir = "fbase_key", K = class {
	constructor(e) {
		this.request = e;
	}
	toPromise() {
		return new Promise((e, t) => {
			this.request.addEventListener("success", () => {
				e(this.request.result);
			}), this.request.addEventListener("error", () => {
				t(this.request.error);
			});
		});
	}
};
function Lr(e, t) {
	return e.transaction([Fr], t ? "readwrite" : "readonly").objectStore(Fr);
}
function Rr() {
	return new K(indexedDB.deleteDatabase(Nr)).toPromise();
}
function zr() {
	let e = indexedDB.open(Nr, Pr);
	return new Promise((t, n) => {
		e.addEventListener("error", () => {
			n(e.error);
		}), e.addEventListener("upgradeneeded", () => {
			let t = e.result;
			try {
				t.createObjectStore(Fr, { keyPath: Ir });
			} catch (e) {
				n(e);
			}
		}), e.addEventListener("success", async () => {
			let n = e.result;
			n.objectStoreNames.contains(Fr) ? t(n) : (n.close(), await Rr(), t(await zr()));
		});
	});
}
async function Br(e, t, n) {
	return new K(Lr(e, !0).put({
		[Ir]: t,
		value: n
	})).toPromise();
}
async function Vr(e, t) {
	let n = await new K(Lr(e, !1).get(t)).toPromise();
	return n === void 0 ? null : n.value;
}
function Hr(e, t) {
	return new K(Lr(e, !0).delete(t)).toPromise();
}
var Ur = 800, Wr = 3, Gr = class {
	registerLifecycleListeners() {
		typeof window < "u" && typeof window.addEventListener == "function" && (window.addEventListener("pagehide", this.onPageHide), window.addEventListener("pageshow", this.onPageShow));
	}
	unregisterLifecycleListeners() {
		typeof window < "u" && typeof window.removeEventListener == "function" && (window.removeEventListener("pagehide", this.onPageHide), window.removeEventListener("pageshow", this.onPageShow));
	}
	constructor() {
		this.type = "LOCAL", this.dbPromise = null, this._shouldAllowMigration = !0, this.listeners = {}, this.localCache = {}, this.pollTimer = null, this.isClosing = !1, this.pendingWrites = 0, this.receiver = null, this.sender = null, this.serviceWorkerReceiverAvailable = !1, this.activeServiceWorker = null, this.onPageHide = () => {
			this.isClosing = !0, this.stopPolling(), this.dbPromise &&= (this.dbPromise.then((e) => e.close()).catch(() => {}), null);
		}, this.onPageShow = () => {
			this.isClosing && (this.isClosing = !1, Object.keys(this.listeners).length > 0 && this.startPolling());
		}, this._workerInitializationPromise = this.initializeServiceWorkerMessaging().then(() => {}, () => {});
	}
	async _openDb() {
		return this.dbPromise || (this.dbPromise = zr(), this.dbPromise.catch(() => {
			this.dbPromise = null;
		})), this.dbPromise;
	}
	async _withRetries(e) {
		let t = 0;
		for (;;) try {
			return await e(await this._openDb());
		} catch (e) {
			if (t++ > Wr) throw e;
			if (this.dbPromise) {
				let e = this.dbPromise;
				this.dbPromise = null;
				try {
					(await e).close();
				} catch {}
			}
		}
	}
	async initializeServiceWorkerMessaging() {
		return kr() ? this.initializeReceiver() : this.initializeSender();
	}
	async initializeReceiver() {
		this.receiver = Tr._getInstance(Mr()), this.receiver._subscribe("keyChanged", async (e, t) => ({ keyProcessed: (await this._poll()).includes(t.key) })), this.receiver._subscribe("ping", async (e, t) => ["keyChanged"]);
	}
	async initializeSender() {
		if (this.activeServiceWorker = await Ar(), !this.activeServiceWorker) return;
		this.sender = new Dr(this.activeServiceWorker);
		let e = await this.sender._send("ping", {}, 800);
		e && e[0]?.fulfilled && e[0]?.value.includes("keyChanged") && (this.serviceWorkerReceiverAvailable = !0);
	}
	async notifyServiceWorker(e) {
		if (this.sender && this.activeServiceWorker && jr() === this.activeServiceWorker) try {
			await this.sender._send("keyChanged", { key: e }, this.serviceWorkerReceiverAvailable ? 800 : 50);
		} catch {}
	}
	async _isAvailable() {
		try {
			return indexedDB ? (await this._withRetries(async (e) => {
				await Br(e, Cr, "1"), await Hr(e, Cr);
			}), !0) : !1;
		} catch {}
		return !1;
	}
	async _withPendingWrite(e) {
		this.pendingWrites++;
		try {
			await e();
		} finally {
			this.pendingWrites--;
		}
	}
	async _set(e, t) {
		return this._withPendingWrite(async () => (await this._withRetries((n) => Br(n, e, t)), this.localCache[e] = t, this.notifyServiceWorker(e)));
	}
	async _get(e) {
		let t = await this._withRetries((t) => Vr(t, e));
		return this.localCache[e] = t, t;
	}
	async _remove(e) {
		return this._withPendingWrite(async () => (await this._withRetries((t) => Hr(t, e)), delete this.localCache[e], this.notifyServiceWorker(e)));
	}
	async _poll() {
		if (this.isClosing) return [];
		try {
			let e = await this._withRetries((e) => new K(Lr(e, !1).getAll()).toPromise());
			if (this.isClosing || !e || this.pendingWrites !== 0) return [];
			let t = [], n = /* @__PURE__ */ new Set();
			if (e.length !== 0) for (let { fbase_key: r, value: i } of e) n.add(r), JSON.stringify(this.localCache[r]) !== JSON.stringify(i) && (this.notifyListeners(r, i), t.push(r));
			for (let e of Object.keys(this.localCache)) this.localCache[e] && !n.has(e) && (this.notifyListeners(e, null), t.push(e));
			return t;
		} catch (e) {
			return this.isClosing || tn(`Firebase Auth cross-tab polling failed with error: ${e}`), [];
		}
	}
	notifyListeners(e, t) {
		this.localCache[e] = t;
		let n = this.listeners[e];
		if (n) for (let e of Array.from(n)) e(t);
	}
	startPolling() {
		this.stopPolling(), this.pollTimer = setInterval(async () => this._poll(), Ur);
	}
	stopPolling() {
		this.pollTimer &&= (clearInterval(this.pollTimer), null);
	}
	_addListener(e, t) {
		Object.keys(this.listeners).length === 0 && (this.startPolling(), this.registerLifecycleListeners()), this.listeners[e] || (this.listeners[e] = /* @__PURE__ */ new Set(), this._get(e)), this.listeners[e].add(t);
	}
	_removeListener(e, t) {
		this.listeners[e] && (this.listeners[e].delete(t), this.listeners[e].size === 0 && delete this.listeners[e]), Object.keys(this.listeners).length === 0 && (this.stopPolling(), this.unregisterLifecycleListeners());
	}
};
Gr.type = "LOCAL";
var Kr = Gr, qr = "@firebase/auth", Jr = "1.13.8", Yr = class {
	constructor(e) {
		this.auth = e, this.internalListeners = /* @__PURE__ */ new Map();
	}
	getUid() {
		return this.assertAuthConfigured(), this.auth.currentUser?.uid || null;
	}
	async getToken(e) {
		return this.assertAuthConfigured(), await this.auth._initializationPromise, this.auth.currentUser ? { accessToken: await this.auth.currentUser.getIdToken(e) } : null;
	}
	addAuthTokenListener(e) {
		if (this.assertAuthConfigured(), this.internalListeners.has(e)) return;
		let t = this.auth.onIdTokenChanged((t) => {
			e(t?.stsTokenManager.accessToken || null);
		});
		this.internalListeners.set(e, t), this.updateProactiveRefresh();
	}
	removeAuthTokenListener(e) {
		this.assertAuthConfigured();
		let t = this.internalListeners.get(e);
		t && (this.internalListeners.delete(e), t(), this.updateProactiveRefresh());
	}
	assertAuthConfigured() {
		F(this.auth._initializationPromise, "dependent-sdk-initialized-before-auth");
	}
	updateProactiveRefresh() {
		this.internalListeners.size > 0 ? this.auth._startProactiveRefresh() : this.auth._stopProactiveRefresh();
	}
};
function Xr(e) {
	switch (e) {
		case "Node": return "node";
		case "ReactNative": return "rn";
		case "Worker": return "webworker";
		case "Cordova": return "cordova";
		case "WebExtension": return "web-extension";
		default: return;
	}
}
function Zr(e) {
	O(new C("auth", (t, { options: n }) => {
		let r = t.getProvider("app").getImmediate(), i = t.getProvider("heartbeat"), a = t.getProvider("app-check-internal"), { apiKey: o, authDomain: s } = r.options;
		F(o && !o.includes(":"), "invalid-api-key", { appName: r.name });
		let c = new nr(r, i, a, {
			apiKey: o,
			authDomain: s,
			clientPlatform: e,
			apiHost: "identitytoolkit.googleapis.com",
			tokenApiHost: "securetoken.googleapis.com",
			apiScheme: "https",
			sdkClientVersion: Zn(e)
		});
		return or(c, n), c;
	}, "PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e, t, n) => {
		e.getProvider("auth-internal").initialize();
	})), O(new C("auth-internal", (e) => ((e) => new Yr(e))(rr(e.getProvider("auth").getImmediate())), "PRIVATE").setInstantiationMode("EXPLICIT")), M(qr, Jr, Xr(e)), M(qr, Jr, "esm2020");
}
// node_modules/@firebase/auth/dist/web-extension-esm/index.js
Zr("WebExtension");
// node_modules/@firebase/functions/dist/esm/index.esm.js
var Qr = "type.googleapis.com/google.protobuf.Int64Value", $r = "type.googleapis.com/google.protobuf.UInt64Value";
function ei(e, t) {
	let n = {};
	for (let r in e) e.hasOwnProperty(r) && (n[r] = t(e[r]));
	return n;
}
function ti(e) {
	if (e == null) return null;
	if (e instanceof Number && (e = e.valueOf()), typeof e == "number" && isFinite(e) || e === !0 || e === !1 || Object.prototype.toString.call(e) === "[object String]") return e;
	if (e instanceof Date) return e.toISOString();
	if (Array.isArray(e)) return e.map((e) => ti(e));
	if (typeof e == "function" || typeof e == "object") return ei(e, (e) => ti(e));
	throw Error("Data cannot be encoded in JSON: " + e);
}
function q(e) {
	if (e == null) return e;
	if (e["@type"]) switch (e["@type"]) {
		case Qr:
		case $r: {
			let t = Number(e.value);
			if (isNaN(t)) throw Error("Data cannot be decoded from JSON: " + e);
			return t;
		}
		default: throw Error("Data cannot be decoded from JSON: " + e);
	}
	return Array.isArray(e) ? e.map((e) => q(e)) : typeof e == "function" || typeof e == "object" ? ei(e, (e) => q(e)) : e;
}
var ni = "functions", ri = {
	OK: "ok",
	CANCELLED: "cancelled",
	UNKNOWN: "unknown",
	INVALID_ARGUMENT: "invalid-argument",
	DEADLINE_EXCEEDED: "deadline-exceeded",
	NOT_FOUND: "not-found",
	ALREADY_EXISTS: "already-exists",
	PERMISSION_DENIED: "permission-denied",
	UNAUTHENTICATED: "unauthenticated",
	RESOURCE_EXHAUSTED: "resource-exhausted",
	FAILED_PRECONDITION: "failed-precondition",
	ABORTED: "aborted",
	OUT_OF_RANGE: "out-of-range",
	UNIMPLEMENTED: "unimplemented",
	INTERNAL: "internal",
	UNAVAILABLE: "unavailable",
	DATA_LOSS: "data-loss"
}, J = class e extends v {
	constructor(t, n, r, i) {
		super(`${ni}/${t}`, n || "", i == null ? void 0 : { url: i }), this.details = r, Object.setPrototypeOf(this, e.prototype);
	}
};
function ii(e) {
	if (e >= 200 && e < 300) return "ok";
	switch (e) {
		case 0: return "internal";
		case 400: return "invalid-argument";
		case 401: return "unauthenticated";
		case 403: return "permission-denied";
		case 404: return "not-found";
		case 409: return "aborted";
		case 429: return "resource-exhausted";
		case 499: return "cancelled";
		case 500: return "internal";
		case 501: return "unimplemented";
		case 503: return "unavailable";
		case 504: return "deadline-exceeded";
	}
	return "unknown";
}
function ai(e, t, n) {
	let r = ii(e), i = r, a;
	try {
		let o = t && t.error;
		if (o) {
			let t = o.status;
			if (typeof t == "string") {
				if (!ri[t]) return new J("internal", `Unknown backend error status: ${t} [${e}]`, void 0, n);
				r = ri[t], i = `Backend error status: ${t}`;
			}
			let s = o.message;
			typeof s == "string" && (i = s), a = o.details, a !== void 0 && (a = q(a));
		}
	} catch {}
	return r === "ok" ? null : new J(r, `${i} [${e}]`, a, n);
}
var oi = class {
	constructor(e, t, n, r) {
		this.app = e, this.auth = null, this.messaging = null, this.appCheck = null, this.serverAppAppCheckToken = null, k(e) && e.settings.appCheckToken && (this.serverAppAppCheckToken = e.settings.appCheckToken), this.auth = t.getImmediate({ optional: !0 }), this.messaging = n.getImmediate({ optional: !0 }), this.auth || t.get().then((e) => this.auth = e, () => {}), this.messaging || n.get().then((e) => this.messaging = e, () => {}), this.appCheck || r?.get().then((e) => this.appCheck = e, () => {});
	}
	async getAuthToken() {
		if (this.auth) try {
			return (await this.auth.getToken())?.accessToken;
		} catch {
			return;
		}
	}
	async getMessagingToken() {
		if (this.messaging && "Notification" in self && Notification.permission === "granted") try {
			return await this.messaging.getToken();
		} catch {
			return;
		}
	}
	async getAppCheckToken(e) {
		if (this.serverAppAppCheckToken) return this.serverAppAppCheckToken;
		if (this.appCheck) {
			let t = e ? await this.appCheck.getLimitedUseToken() : await this.appCheck.getToken();
			return t.error ? null : t.token;
		}
		return null;
	}
	async getContext(e) {
		return {
			authToken: await this.getAuthToken(),
			messagingToken: await this.getMessagingToken(),
			appCheckToken: await this.getAppCheckToken(e)
		};
	}
}, si = "us-central1", ci = /^data: (.*?)(?:\n|$)/;
function li(e) {
	let t = null;
	return {
		promise: new Promise((n, r) => {
			t = setTimeout(() => {
				r(new J("deadline-exceeded", "deadline-exceeded"));
			}, e);
		}),
		cancel: () => {
			t && clearTimeout(t);
		}
	};
}
var ui = class {
	constructor(e, t, n, r, i = si, a = (...e) => fetch(...e)) {
		this.app = e, this.fetchImpl = a, this.emulatorOrigin = null, this.contextProvider = new oi(e, t, n, r), this.cancelAllRequests = new Promise((e) => {
			this.deleteService = () => Promise.resolve(e());
		});
		try {
			let e = new URL(i);
			this.customDomain = e.origin + (e.pathname === "/" ? "" : e.pathname), this.region = si;
		} catch {
			this.customDomain = null, this.region = i;
		}
	}
	_delete() {
		return this.deleteService();
	}
	_url(e) {
		let t = this.app.options.projectId;
		return this.emulatorOrigin === null ? this.customDomain === null ? `https://${this.region}-${t}.cloudfunctions.net/${e}` : `${this.customDomain}/${e}` : `${this.emulatorOrigin}/${t}/${this.region}/${e}`;
	}
};
function di(e, t, n) {
	let r = S(t);
	e.emulatorOrigin = `http${r ? "s" : ""}://${t}:${n}`, r && he(e.emulatorOrigin + "/backends");
}
function fi(e, t, n) {
	let r = (r) => gi(e, t, r, n || {});
	return r.stream = (n, r) => vi(e, t, n, r), r;
}
function pi(e) {
	return e.emulatorOrigin && S(e.emulatorOrigin) ? "include" : void 0;
}
async function mi(e, t, n, r, i) {
	n["Content-Type"] = "application/json";
	let a;
	try {
		a = await r(e, {
			method: "POST",
			body: JSON.stringify(t),
			headers: n,
			credentials: pi(i)
		});
	} catch {
		return {
			status: 0,
			json: null
		};
	}
	let o = null;
	try {
		o = await a.json();
	} catch {}
	return {
		status: a.status,
		json: o
	};
}
async function hi(e, t) {
	let n = {}, r = await e.contextProvider.getContext(t.limitedUseAppCheckTokens);
	return r.authToken && (n.Authorization = "Bearer " + r.authToken), r.messagingToken && (n["Firebase-Instance-ID-Token"] = r.messagingToken), r.appCheckToken !== null && (n["X-Firebase-AppCheck"] = r.appCheckToken), n;
}
function gi(e, t, n, r) {
	return _i(e, e._url(t), n, r);
}
async function _i(e, t, n, r) {
	n = ti(n);
	let i = { data: n }, a = await hi(e, r), o = li(r.timeout || 7e4), s = await Promise.race([
		mi(t, i, a, e.fetchImpl, e),
		o.promise,
		e.cancelAllRequests
	]);
	if (o.cancel(), !s) throw new J("cancelled", "Firebase Functions instance was deleted.");
	let c = ai(s.status, s.json, t);
	if (c) throw c;
	if (!s.json) throw new J("internal", "Response is not valid JSON object.", void 0, t);
	let l = s.json.data;
	if (l === void 0 && (l = s.json.result), l === void 0) throw new J("internal", "Response is missing data field.", void 0, t);
	return { data: q(l) };
}
function vi(e, t, n, r) {
	return yi(e, e._url(t), n, r || {});
}
async function yi(e, t, n, r) {
	n = ti(n);
	let i = { data: n }, a = await hi(e, r);
	a["Content-Type"] = "application/json", a.Accept = "text/event-stream";
	let o;
	try {
		o = await e.fetchImpl(t, {
			method: "POST",
			body: JSON.stringify(i),
			headers: a,
			signal: r?.signal,
			credentials: pi(e)
		});
	} catch (e) {
		if (e instanceof Error && e.name === "AbortError") {
			let e = new J("cancelled", "Request was cancelled.");
			return {
				data: Promise.reject(e),
				stream: { [Symbol.asyncIterator]() {
					return { next() {
						return Promise.reject(e);
					} };
				} }
			};
		}
		let n = ai(0, null, t);
		return {
			data: Promise.reject(n),
			stream: { [Symbol.asyncIterator]() {
				return { next() {
					return Promise.reject(n);
				} };
			} }
		};
	}
	let s, c, l = new Promise((e, t) => {
		s = e, c = t;
	});
	r?.signal?.addEventListener("abort", () => {
		let e = new J("cancelled", "Request was cancelled.");
		c(e);
	});
	let u = bi(o.body.getReader(), s, c, r?.signal, t);
	return {
		stream: { [Symbol.asyncIterator]() {
			let e = u.getReader();
			return {
				async next() {
					let { value: t, done: n } = await e.read();
					return {
						value: t,
						done: n
					};
				},
				async return() {
					return await e.cancel(), {
						done: !0,
						value: void 0
					};
				}
			};
		} },
		data: l
	};
}
function bi(e, t, n, r, i) {
	let a = (e, r) => {
		let a = e.match(ci);
		if (!a) return;
		let o = a[1];
		try {
			let e = JSON.parse(o);
			if ("result" in e) {
				t(q(e.result));
				return;
			}
			if ("message" in e) {
				r.enqueue(q(e.message));
				return;
			}
			if ("error" in e) {
				let t = ai(0, e, i);
				r.error(t), n(t);
				return;
			}
		} catch (e) {
			if (e instanceof J) {
				r.error(e), n(e);
				return;
			}
		}
	}, o = new TextDecoder();
	return new ReadableStream({
		start(t) {
			let s = "";
			return c();
			async function c() {
				if (r?.aborted) {
					let e = new J("cancelled", "Request was cancelled");
					return t.error(e), n(e), Promise.resolve();
				}
				try {
					let { value: i, done: l } = await e.read();
					if (l) {
						s.trim() && a(s.trim(), t), t.close();
						return;
					}
					if (r?.aborted) {
						let r = new J("cancelled", "Request was cancelled");
						t.error(r), n(r), await e.cancel();
						return;
					}
					s += o.decode(i, { stream: !0 });
					let u = s.split("\n");
					s = u.pop() || "";
					for (let e of u) e.trim() && a(e.trim(), t);
					return c();
				} catch (e) {
					let r = e instanceof J ? e : ai(0, null, i);
					t.error(r), n(r);
				}
			}
		},
		cancel() {
			return e.cancel();
		}
	});
}
var xi = "@firebase/functions", Si = "0.14.0", Ci = "auth-internal", wi = "app-check-internal", Ti = "messaging-internal";
function Ei(e) {
	O(new C(ni, (e, { instanceIdentifier: t }) => new ui(e.getProvider("app").getImmediate(), e.getProvider(Ci), e.getProvider(Ti), e.getProvider(wi), t), "PUBLIC").setMultipleInstances(!0)), M(xi, Si, e), M(xi, Si, "esm2020");
}
function Di(e = Pt(), t = si) {
	let n = jt(x(e), ni).getImmediate({ identifier: t }), r = m("functions");
	return r && Oi(n, ...r), n;
}
function Oi(e, t, n) {
	di(x(e), t, n);
}
function ki(e, t, n) {
	return fi(x(e), t, n);
}
Ei();
// node_modules/@firebase/storage/dist/index.esm.js
var Ai = "firebasestorage.googleapis.com", ji = "storageBucket", Mi = 12e4, Ni = 6e5, Y = class e extends v {
	constructor(t, n, r = 0) {
		super(Pi(t), `Firebase Storage: ${n} (${Pi(t)})`), this.status_ = r, this.customData = { serverResponse: null }, this._baseMessage = this.message, Object.setPrototypeOf(this, e.prototype);
	}
	get status() {
		return this.status_;
	}
	set status(e) {
		this.status_ = e;
	}
	_codeEquals(e) {
		return Pi(e) === this.code;
	}
	get serverResponse() {
		return this.customData.serverResponse;
	}
	set serverResponse(e) {
		this.customData.serverResponse = e, this.message = this.customData.serverResponse ? `${this._baseMessage}\n${this.customData.serverResponse}` : this._baseMessage;
	}
}, X;
(function(e) {
	e.UNKNOWN = "unknown", e.OBJECT_NOT_FOUND = "object-not-found", e.BUCKET_NOT_FOUND = "bucket-not-found", e.PROJECT_NOT_FOUND = "project-not-found", e.QUOTA_EXCEEDED = "quota-exceeded", e.UNAUTHENTICATED = "unauthenticated", e.UNAUTHORIZED = "unauthorized", e.UNAUTHORIZED_APP = "unauthorized-app", e.RETRY_LIMIT_EXCEEDED = "retry-limit-exceeded", e.INVALID_CHECKSUM = "invalid-checksum", e.CANCELED = "canceled", e.INVALID_EVENT_NAME = "invalid-event-name", e.INVALID_URL = "invalid-url", e.INVALID_DEFAULT_BUCKET = "invalid-default-bucket", e.NO_DEFAULT_BUCKET = "no-default-bucket", e.CANNOT_SLICE_BLOB = "cannot-slice-blob", e.SERVER_FILE_WRONG_SIZE = "server-file-wrong-size", e.NO_DOWNLOAD_URL = "no-download-url", e.INVALID_ARGUMENT = "invalid-argument", e.INVALID_ARGUMENT_COUNT = "invalid-argument-count", e.APP_DELETED = "app-deleted", e.INVALID_ROOT_OPERATION = "invalid-root-operation", e.INVALID_FORMAT = "invalid-format", e.INTERNAL_ERROR = "internal-error", e.UNSUPPORTED_ENVIRONMENT = "unsupported-environment";
})(X ||= {});
function Pi(e) {
	return "storage/" + e;
}
function Fi() {
	return new Y(X.UNKNOWN, "An unknown error occurred, please check the error payload for server response.");
}
function Ii() {
	return new Y(X.RETRY_LIMIT_EXCEEDED, "Max retry time for operation exceeded, please try again.");
}
function Li() {
	return new Y(X.CANCELED, "User canceled the upload/download.");
}
function Ri(e) {
	return new Y(X.INVALID_URL, "Invalid URL '" + e + "'.");
}
function zi(e) {
	return new Y(X.INVALID_DEFAULT_BUCKET, "Invalid default bucket '" + e + "'.");
}
function Bi(e) {
	return new Y(X.INVALID_ARGUMENT, e);
}
function Vi() {
	return new Y(X.APP_DELETED, "The Firebase app was deleted.");
}
function Hi(e) {
	return new Y(X.INVALID_ROOT_OPERATION, "The operation '" + e + "' cannot be performed on a root reference, create a non-root reference using child, such as .child('file.png').");
}
var Z = class e {
	constructor(e, t) {
		this.bucket = e, this.path_ = t;
	}
	get path() {
		return this.path_;
	}
	get isRoot() {
		return this.path.length === 0;
	}
	fullServerUrl() {
		let e = encodeURIComponent;
		return "/b/" + e(this.bucket) + "/o/" + e(this.path);
	}
	bucketOnlyServerUrl() {
		return "/b/" + encodeURIComponent(this.bucket) + "/o";
	}
	static makeFromBucketSpec(t, n) {
		let r;
		try {
			r = e.makeFromUrl(t, n);
		} catch {
			return new e(t, "");
		}
		if (r.path === "") return r;
		throw zi(t);
	}
	static makeFromUrl(t, n) {
		let r = null, i = "([A-Za-z0-9.\\-_]+)";
		function a(e) {
			e.path.charAt(e.path.length - 1) === "/" && (e.path_ = e.path_.slice(0, -1));
		}
		let o = RegExp("^gs://" + i + "(/(.*))?$", "i"), s = {
			bucket: 1,
			path: 3
		};
		function c(e) {
			e.path_ = decodeURIComponent(e.path);
		}
		let l = n.replace(/[.]/g, "\\."), u = RegExp(`^https?://${l}/v[A-Za-z0-9_]+/b/${i}/o(/([^?#]*).*)?\$`, "i"), d = {
			bucket: 1,
			path: 3
		}, f = RegExp(`^https?://${n === Ai ? "(?:storage.googleapis.com|storage.cloud.google.com)" : n}/${i}/([^?#]*)`, "i"), p = [
			{
				regex: o,
				indices: s,
				postModify: a
			},
			{
				regex: u,
				indices: d,
				postModify: c
			},
			{
				regex: f,
				indices: {
					bucket: 1,
					path: 2
				},
				postModify: c
			}
		];
		for (let n = 0; n < p.length; n++) {
			let i = p[n], a = i.regex.exec(t);
			if (a) {
				let t = a[i.indices.bucket], n = a[i.indices.path];
				n ||= "", r = new e(t, n), i.postModify(r);
				break;
			}
		}
		if (r == null) throw Ri(t);
		return r;
	}
}, Ui = class {
	constructor(e) {
		this.promise_ = Promise.reject(e);
	}
	getPromise() {
		return this.promise_;
	}
	cancel(e = !1) {}
};
function Wi(e, t, n) {
	let r = 1, i = null, a = null, o = !1, s = 0;
	function c() {
		return s === 2;
	}
	let l = !1;
	function u(...e) {
		l || (l = !0, t.apply(null, e));
	}
	function d(t) {
		i = setTimeout(() => {
			i = null, e(p, c());
		}, t);
	}
	function f() {
		a && clearTimeout(a);
	}
	function p(e, ...t) {
		if (l) {
			f();
			return;
		}
		if (e || c() || o) {
			f(), u.call(null, e, ...t);
			return;
		}
		r < 64 && (r *= 2);
		let n;
		s === 1 ? (s = 2, n = 0) : n = (r + Math.random()) * 1e3, d(n);
	}
	let m = !1;
	function h(e) {
		m || (m = !0, f(), !l && (i === null ? e || (s = 1) : (e || (s = 2), clearTimeout(i), d(0))));
	}
	return d(0), a = setTimeout(() => {
		o = !0, h(!0);
	}, n), h;
}
function Gi(e) {
	e(!1);
}
function Ki(e) {
	return e !== void 0;
}
function qi(e, t, n, r) {
	if (r < t) throw Bi(`Invalid value for '${e}'. Expected ${t} or greater.`);
	if (r > n) throw Bi(`Invalid value for '${e}'. Expected ${n} or less.`);
}
function Ji(e) {
	let t = encodeURIComponent, n = "?";
	for (let r in e) if (e.hasOwnProperty(r)) {
		let i = t(r) + "=" + t(e[r]);
		n = n + i + "&";
	}
	return n = n.slice(0, -1), n;
}
var Yi;
(function(e) {
	e[e.NO_ERROR = 0] = "NO_ERROR", e[e.NETWORK_ERROR = 1] = "NETWORK_ERROR", e[e.ABORT = 2] = "ABORT";
})(Yi ||= {});
function Xi(e, t) {
	let n = e >= 500 && e < 600, r = [408, 429].indexOf(e) !== -1, i = t.indexOf(e) !== -1;
	return n || r || i;
}
var Zi = class {
	constructor(e, t, n, r, i, a, o, s, c, l, u, d = !0, f = !1) {
		this.url_ = e, this.method_ = t, this.headers_ = n, this.body_ = r, this.successCodes_ = i, this.additionalRetryCodes_ = a, this.callback_ = o, this.errorCallback_ = s, this.timeout_ = c, this.progressCallback_ = l, this.connectionFactory_ = u, this.retry = d, this.isUsingEmulator = f, this.pendingConnection_ = null, this.backoffId_ = null, this.canceled_ = !1, this.appDelete_ = !1, this.promise_ = new Promise((e, t) => {
			this.resolve_ = e, this.reject_ = t, this.start_();
		});
	}
	start_() {
		let e = (e, t) => {
			if (t) {
				e(!1, new Qi(!1, null, !0));
				return;
			}
			let n = this.connectionFactory_();
			this.pendingConnection_ = n;
			let r = (e) => {
				let t = e.loaded, n = e.lengthComputable ? e.total : -1;
				this.progressCallback_ !== null && this.progressCallback_(t, n);
			};
			this.progressCallback_ !== null && n.addUploadProgressListener(r), n.send(this.url_, this.method_, this.isUsingEmulator, this.body_, this.headers_).then(() => {
				this.progressCallback_ !== null && n.removeUploadProgressListener(r), this.pendingConnection_ = null;
				let t = n.getErrorCode() === Yi.NO_ERROR, i = n.getStatus();
				!t || Xi(i, this.additionalRetryCodes_) && this.retry ? e(!1, new Qi(!1, null, n.getErrorCode() === Yi.ABORT)) : e(!0, new Qi(this.successCodes_.indexOf(i) !== -1, n));
			});
		}, t = (e, t) => {
			let n = this.resolve_, r = this.reject_, i = t.connection;
			if (t.wasSuccessCode) try {
				let e = this.callback_(i, i.getResponse());
				Ki(e) ? n(e) : n();
			} catch (e) {
				r(e);
			}
			else if (i !== null) {
				let e = Fi();
				e.serverResponse = i.getErrorText(), this.errorCallback_ ? r(this.errorCallback_(i, e)) : r(e);
			} else t.canceled ? r(this.appDelete_ ? Vi() : Li()) : r(Ii());
		};
		this.canceled_ ? t(!1, new Qi(!1, null, !0)) : this.backoffId_ = Wi(e, t, this.timeout_);
	}
	getPromise() {
		return this.promise_;
	}
	cancel(e) {
		this.canceled_ = !0, this.appDelete_ = e || !1, this.backoffId_ !== null && Gi(this.backoffId_), this.pendingConnection_ !== null && this.pendingConnection_.abort();
	}
}, Qi = class {
	constructor(e, t, n) {
		this.wasSuccessCode = e, this.connection = t, this.canceled = !!n;
	}
};
function $i(e, t) {
	t !== null && t.length > 0 && (e.Authorization = "Firebase " + t);
}
function ea(e, t) {
	e["X-Firebase-Storage-Version"] = "webjs/" + (t ?? "AppManager");
}
function ta(e, t) {
	t && (e["X-Firebase-GMPID"] = t);
}
function na(e, t) {
	t !== null && (e["X-Firebase-AppCheck"] = t);
}
function ra(e, t, n, r, i, a, o = !0, s = !1) {
	let c = Ji(e.urlParams), l = e.url + c, u = Object.assign({}, e.headers);
	return ta(u, t), $i(u, n), ea(u, a), na(u, r), new Zi(l, e.method, u, e.body, e.successCodes, e.additionalRetryCodes, e.handler, e.errorHandler, e.timeout, e.progressCallback, i, o, s);
}
function ia(e) {
	if (e.length === 0) return null;
	let t = e.lastIndexOf("/");
	return t === -1 ? "" : e.slice(0, t);
}
function aa(e) {
	let t = e.lastIndexOf("/", e.length - 2);
	return t === -1 ? e : e.slice(t + 1);
}
var oa = class e {
	constructor(e, t) {
		this._service = e, this._location = t instanceof Z ? t : Z.makeFromUrl(t, e.host);
	}
	toString() {
		return "gs://" + this._location.bucket + "/" + this._location.path;
	}
	_newRef(t, n) {
		return new e(t, n);
	}
	get root() {
		let e = new Z(this._location.bucket, "");
		return this._newRef(this._service, e);
	}
	get bucket() {
		return this._location.bucket;
	}
	get fullPath() {
		return this._location.path;
	}
	get name() {
		return aa(this._location.path);
	}
	get storage() {
		return this._service;
	}
	get parent() {
		let t = ia(this._location.path);
		if (t === null) return null;
		let n = new Z(this._location.bucket, t);
		return new e(this._service, n);
	}
	_throwIfRoot(e) {
		if (this._location.path === "") throw Hi(e);
	}
};
function sa(e, t) {
	let n = t?.[ji];
	return n == null ? null : Z.makeFromBucketSpec(n, e);
}
function ca(e, t, n, r = {}) {
	e.host = `${t}:${n}`;
	let i = S(t);
	i && he(`https://${e.host}/b`).catch(() => {}), e._isUsingEmulator = !0, e._protocol = i ? "https" : "http";
	let { mockUserToken: a } = r;
	a && (e._overrideAuthToken = typeof a == "string" ? a : g(a, e.app.options.projectId));
}
var la = class {
	constructor(e, t, n, r, i, a = !1) {
		this.app = e, this._authProvider = t, this._appCheckProvider = n, this._url = r, this._firebaseVersion = i, this._isUsingEmulator = a, this._bucket = null, this._host = Ai, this._protocol = "https", this._appId = null, this._deleted = !1, this._maxOperationRetryTime = Mi, this._maxUploadRetryTime = Ni, this._requests = /* @__PURE__ */ new Set(), this._bucket = r == null ? sa(this._host, this.app.options) : Z.makeFromBucketSpec(r, this._host);
	}
	get host() {
		return this._host;
	}
	set host(e) {
		this._host = e, this._bucket = this._url == null ? sa(e, this.app.options) : Z.makeFromBucketSpec(this._url, e);
	}
	get maxUploadRetryTime() {
		return this._maxUploadRetryTime;
	}
	set maxUploadRetryTime(e) {
		qi("time", 0, Infinity, e), this._maxUploadRetryTime = e;
	}
	get maxOperationRetryTime() {
		return this._maxOperationRetryTime;
	}
	set maxOperationRetryTime(e) {
		qi("time", 0, Infinity, e), this._maxOperationRetryTime = e;
	}
	async _getAuthToken() {
		if (this._overrideAuthToken) return this._overrideAuthToken;
		let e = this._authProvider.getImmediate({ optional: !0 });
		if (e) {
			let t = await e.getToken();
			if (t !== null) return t.accessToken;
		}
		return null;
	}
	async _getAppCheckToken() {
		if (k(this.app) && this.app.settings.appCheckToken) return this.app.settings.appCheckToken;
		let e = this._appCheckProvider.getImmediate({ optional: !0 });
		return e ? (await e.getToken()).token : null;
	}
	_delete() {
		return this._deleted || (this._deleted = !0, this._requests.forEach((e) => e.cancel()), this._requests.clear()), Promise.resolve();
	}
	_makeStorageReference(e) {
		return new oa(this, e);
	}
	_makeRequest(e, t, n, r, i = !0) {
		if (this._deleted) return new Ui(Vi());
		{
			let a = ra(e, this._appId, n, r, t, this._firebaseVersion, i, this._isUsingEmulator);
			return this._requests.add(a), a.getPromise().then(() => this._requests.delete(a), () => this._requests.delete(a)), a;
		}
	}
	async makeRequestWithTokens(e, t) {
		let [n, r] = await Promise.all([this._getAuthToken(), this._getAppCheckToken()]);
		return this._makeRequest(e, t, n, r).getPromise();
	}
}, ua = "@firebase/storage", da = "0.14.6", fa = "storage";
function pa(e = Pt(), t) {
	e = x(e);
	let n = jt(e, fa).getImmediate({ identifier: t }), r = m("storage");
	return r && ma(n, ...r), n;
}
function ma(e, t, n, r = {}) {
	ca(e, t, n, r);
}
function ha(e, { instanceIdentifier: t }) {
	return new la(e.getProvider("app").getImmediate(), e.getProvider("auth-internal"), e.getProvider("app-check-internal"), t, j);
}
function ga() {
	O(new C(fa, ha, "PUBLIC").setMultipleInstances(!0)), M(ua, da, ""), M(ua, da, "esm2020");
}
ga();
// packages/client.ts
var Q = {
	BASE_URL: "/",
	DEV: !1,
	MODE: "production",
	PROD: !0,
	SSR: !1,
	VITE_FIREBASE_API_KEY: "AIzaSyC41WxbOIS67hWUVsPspQdvDaKzh5mIp5A",
	VITE_FIREBASE_APP_ID: "1:927303919000:web:f086b6f31318391e4bb7ed",
	VITE_FIREBASE_AUTH_DOMAIN: "groupposter-1f253.firebaseapp.com",
	VITE_FIREBASE_PROJECT_ID: "groupposter-1f253"
}, $ = Q.VITE_EMULATOR === "true";
$ || Q.VITE_FIREBASE_API_KEY && Q.VITE_FIREBASE_APP_ID;
var _a = Nt({
	apiKey: $ ? "demo-key" : Q.VITE_FIREBASE_API_KEY || "unconfigured",
	appId: Q.VITE_FIREBASE_APP_ID || "",
	projectId: $ ? "demo-autogroupposter" : Q.VITE_FIREBASE_PROJECT_ID || "groupposter-1f253",
	authDomain: Q.VITE_FIREBASE_AUTH_DOMAIN || "groupposter-1f253.firebaseapp.com",
	storageBucket: $ ? "demo-autogroupposter.appspot.com" : "groupposter-1f253.firebasestorage.app"
}), va = ar(_a, { persistence: Kr }), ya = Di(_a, "us-central1");
$ && (sr(va, "http://127.0.0.1:9195", { disableWarnings: !0 }), Oi(ya, "127.0.0.1", 5105), ma(pa(_a), "127.0.0.1", 9295));
async function ba(e, t = {}) {
	return (await ki(ya, "agpApi")({
		action: e,
		input: t
	})).data;
}
// apps/chrome-extension/src/background.ts
var xa = new Promise((e) => {
	let t = Sr(va, () => {
		t(), e(!0);
	});
});
chrome.runtime.onInstalled.addListener(() => {
	chrome.alarms.create("agp-sync", { periodInMinutes: 1 }), chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: !1 });
}), chrome.runtime.onStartup.addListener(() => {
	chrome.alarms.create("agp-sync", { periodInMinutes: 1 });
}), chrome.alarms.onAlarm.addListener((e) => {
	e.name === "agp-sync" && Sa();
});
async function Sa() {
	if (await xa, !va.currentUser?.emailVerified) return;
	let { deviceId: e } = await chrome.storage.local.get("deviceId");
	if (e) try {
		let t = await ba("jobs", { deviceId: e });
		await chrome.storage.local.set({
			pendingJobs: t.length,
			lastSync: Date.now(),
			syncError: null
		}), await chrome.action.setBadgeText({ text: t.length ? String(t.length) : "" }), await chrome.action.setBadgeBackgroundColor({ color: "#137F72" });
	} catch {
		await chrome.storage.local.set({ syncError: "Sync unavailable. Open AutoGroupPoster to reconnect." });
	}
}
chrome.runtime.onMessage.addListener((e, t, n) => {
	if (e?.type === "SYNC") return Sa().then(() => n({ ok: !0 })).catch(() => n({ ok: !1 })), !0;
});
